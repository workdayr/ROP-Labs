/* C2 - ret2libc portatil con la API ROP() de pwntools.
 * Serie: Laboratorio de Practicas ROP - Parte 3 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o c2_ropapi c2_ropapi.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * Mismo objetivo que B2 (system("/bin/sh") con ASLR desactivada) pero
 * la cadena la ARMA pwntools: rop.call(), rop.raw(), rop.chain() y
 * rop.dump(). El binario dinamico moderno NO trae "pop rdi; ret"
 * (pitfall de la Parte 2): los gadgets salen de libc, cuya base fija
 * revela `setarch $(uname -m) -R ldd ./c2_ropapi`.
 *
 * setvbuf(stdin, _IONBF) es imprescindible: sin el, el shell hereda un
 * stdin bufferizado y los comandos que le envies se los come gets()
 * o el propio stdio (pitfall de la Parte 3, C4). */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[C2] victima() lista; yo no toco libc, pero libc si\n");
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: desbordamiento clasico hasta el retorno guardado. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[C2] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- el ret arranca la cadena que armo ROP() */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* pipes ordenados */
    setvbuf(stdin, NULL, _IONBF, 0);   /* el shell necesita stdin limpio */
    printf("[C2] PID=%d | objetivo: system(\"/bin/sh\") via API ROP()\n",
           getpid());
    victima();
    printf("[C2] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
