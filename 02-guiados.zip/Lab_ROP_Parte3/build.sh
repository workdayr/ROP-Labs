#!/bin/sh
# build.sh - Laboratorio de Practicas ROP, Parte 3 (retos guiados C1-C6)
# Compila los 6 binarios EXACTAMENTE con las banderas impresas en el PDF.
# Uso:  cd ~/rop-lab/parte3 && sh build.sh
set -e

echo "[build.sh] Compilando los retos guiados C1-C6..."

# C1 - caza de gadgets: binario ESTATICO (inventario grande de gadgets)
gcc -g -O0 -fno-stack-protector -no-pie -static -o c1_caza c1_caza.c

# C2 - API ROP() de pwntools: dinamico, gadgets de libc (ASLR fuera)
gcc -g -O0 -fno-stack-protector -no-pie -o c2_ropapi c2_ropapi.c

# C3 - win(int,int): dinamico con gadgets embebidos (g_pop_rdi/g_pop_rsi)
gcc -g -O0 -fno-stack-protector -no-pie -o c3_win2args c3_win2args.c

# C4 - explotacion remota via socat: dinamico, ret2win simple
gcc -g -O0 -fno-stack-protector -no-pie -o c4_servir c4_servir.c

# C5 - leak de libc en dos etapas con ASLR ACTIVADA
gcc -g -O0 -fno-stack-protector -no-pie -o c5_leak c5_leak.c

# C6 - integrador: alineacion + 2 argumentos + llamada doble
gcc -g -O0 -fno-stack-protector -no-pie -o c6_final c6_final.c

echo "[build.sh] 6 binarios listos. Notas:"
echo "  - El warning 'gets is dangerous' es ESPERADO: es la vulnerabilidad."
echo "  - C2 y C6 se explotan con ASLR desactivada:"
echo "      setarch \$(uname -m) -R ./c2_ropapi"
echo "    y su base de libc se lee con:"
echo "      setarch \$(uname -m) -R ldd ./c2_ropapi"
echo "  - C5 se explota con ASLR ACTIVADA (la gracia es el leak)."
echo "  - C4 se sirve con:  socat TCP-LISTEN:1337,reuseaddr,fork EXEC:./c4_servir"
