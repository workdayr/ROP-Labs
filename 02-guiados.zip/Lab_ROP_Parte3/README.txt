================================================================
 LABORATORIO DE PRACTICAS ROP - PARTE 3 DE 4: RETOS GUIADOS
 x86_64 - Kali Linux - pwntools
================================================================

CONTENIDO
---------
6 retos guiados (C1-C6), cada uno con su fuente C y su solucion
pwntools verificada:

  C1  c1_caza.c      / c1_caza.py      Caza de gadgets en binario
                                       ESTATICO + cadena RDI+RSI
                                       a mano (print_flag 0x1337/0x7331)
  C2  c2_ropapi.c    / c2_ropapi.py    ret2libc con la API ROP([elf,
                                       libc]): rop.call/rop.raw/dump
  C3  c3_win2args.c  / c3_win2args.py  win(int,int): DOS valores
                                       magicos (0xdeadbeef/0xc0ffee00)
                                       con gadgets embebidos
  C4  c4_servir.c    / c4_servir.py    Explotacion REMOTA: socat +
                                       remote('127.0.0.1', 1337)
  C5  c5_leak.c      / c5_leak.py      Leak de libc en dos etapas con
                                       ASLR ACTIVADA (puts(puts@GOT))
  C6  c6_final.c     / c6_final.py     Integrador: alineacion + 2
                                       argumentos + llamada doble
                                       (flag + shell en una entrada)
  build.sh           Compila los 6 binarios con las banderas exactas
                     del PDF.

INSTALACION RAPIDA
------------------
  mkdir -p ~/rop-lab/parte3 && cd ~/rop-lab/parte3
  # copia aqui los archivos de este ZIP
  sh build.sh

El script compila los 6 binarios. El warning "the `gets' function is
dangerous" es ESPERADO: gets() es la vulnerabilidad.

COMO TRABAJAR CADA RETO
-----------------------
1. Lee el enunciado y el codigo C (apartados a-b del PDF).
2. Intenta resolverlo SIN leer las pistas.
3. Si te atascas, sube por las pistas: Pista 1 (conceptual) ->
   Pista 2 (tecnica) -> Pista 3 (estructura del payload).
4. El plan de alto nivel (apartado f) te guia sin darte codigo.
5. La solucion completa (apartado g) es el ULTIMO recurso.
6. Anota fecha, tiempo y peldaño en la Tabla 3 del apendice.

NOTAS POR RETO
--------------
- C1: no requiere setarch (binario estatico, No PIE).
- C2: SIEMPRE lanza el binario con la misma via que el ldd:
      setarch $(uname -m) -R ./c2_ropapi
      setarch $(uname -m) -R ldd ./c2_ropapi
- C3: sin setarch; los gadgets g_pop_rdi/g_pop_rsi/g_ret estan
      embebidos en el binario (verificalos con ROPgadget).
- C4: levanta el servicio antes de ejecutar el exploit:
      socat TCP-LISTEN:1337,reuseaddr,fork EXEC:./c4_servir
- C5: ASLR ACTIVADA (sin setarch): la gracia es el leak. Si el leak
      sale truncado (un byte 0x0a en la direccion), el exploit
      reintenta solo con una ejecucion nueva.
- C6: mezcla embebidos + base de libc via setarch -R ldd.

ETICA
-----
Estos binarios son para practicar en TU VM Kali aislada. Las tecnicas
del laboratorio son ilegales contra sistemas de terceros sin
autorizacion por escrito. Solo binarios propios, solo laboratorio.

Serie: Parte 1 (A0-A4) - Parte 2 (B1-B4) - Parte 3 (C1-C6) -
Parte 4 (CTF-01..06).
