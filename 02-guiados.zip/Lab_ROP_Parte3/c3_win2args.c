/* C3 - win(int, int): DOS valores magicos por RDI y RSI.
 * Serie: Laboratorio de Practicas ROP - Parte 3 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o c3_win2args c3_win2args.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * win(int a, int b) exige (RDI=0xdeadbeef, RSI=0xc0ffee00). El binario
 * dinamico moderno no trae trampolines propios (pitfall de la Parte 2),
 * asi que esta vez los gadgets VIENEN EMBEBIDOS en el fuente con asm
 * inline, como hacen los autores de retos cuando quieren que el binario
 * sea resoluble sin depender de libc: g_pop_rdi, g_pop_rsi y g_ret.
 * Verificalos tu mismo con ROPgadget --binary ./c3_win2args --only "pop|ret"
 *
 * No necesitas setarch: sin PIE, los simbolos y gadgets quedan en
 * direcciones fijas aunque ASLR este activada. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Gadgets embebidos: etiquetas globales apuntando a instrucciones
 * exactas. El ensamblador las coloca en .text y nm/ROPgadget las ven. */
__asm__(
    ".globl g_pop_rdi\n"
    "g_pop_rdi:\n"
    "    pop %rdi\n"
    "    ret\n"
    ".globl g_pop_rsi\n"
    "g_pop_rsi:\n"
    "    pop %rsi\n"
    "    ret\n"
    ".globl g_ret\n"
    "g_ret:\n"
    "    ret\n"
);

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void win(int a, int b)
{
    if (a == 0xdeadbeef && b == 0xc0ffee00) {
        printf("[win] FLAG{ROP_C3_dos_valores_magicos}\n");
    } else {
        printf("[win] argumentos incorrectos: (0x%x, 0x%x); "
               "esperaba (0xdeadbeef, 0xc0ffee00)\n", (unsigned int)a,
               (unsigned int)b);
    }
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[C3] victima() en ejecucion; win() pide DOS valores magicos\n");
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: gets() sin limite; la entrada sobra hasta el retorno. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[C3] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- el ret arranca tu cadena de gadgets */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: util para pipes */
    printf("[C3] PID=%d | win(0xdeadbeef, 0xc0ffee00) por RDI y RSI\n",
           getpid());
    victima();
    printf("[C3] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
