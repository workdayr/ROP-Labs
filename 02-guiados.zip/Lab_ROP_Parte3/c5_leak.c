/* C5 - Leak de libc en dos etapas con ASLR ACTIVADA.
 * Serie: Laboratorio de Practicas ROP - Parte 3 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o c5_leak c5_leak.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * Hoy no hay setarch ni ldd que valgan: ASLR activada significa que la
 * base de libc cambia en cada ejecucion. La salida tiene DOS etapas:
 *   Etapa 1: puts(puts@GOT) imprime la direccion REAL de puts y la
 *            cadena devuelve el control a victima() (simbolo del propio
 *            binario, fijo por No PIE).
 *   Etapa 2: libc_base = leak - offset_de_puts; recalculas system y
 *            "/bin/sh" y lanzas el ret2libc de siempre.
 *
 * El trampolin g_pop_rdi viene EMBEBIDO (asm inline): es lo que un
 * autor de retos hace cuando el binario dinamico moderno no trae
 * gadgets propios y la etapa 1 no puede depender de libc todavia. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Gadgets embebidos: imprescindibles para la etapa 1, cuando libc aun
 * es un misterio. Verificalos: ROPgadget --binary ./c5_leak --only "pop|ret" */
__asm__(
    ".globl g_pop_rdi\n"
    "g_pop_rdi:\n"
    "    pop %rdi\n"
    "    ret\n"
    ".globl g_ret\n"
    "g_ret:\n"
    "    ret\n"
);

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    puts("[C5] victima() abierta; cada visita acepta UNA linea:");
    /* VULNERABLE: gets() sin limite; la funcion sera visitada DOS veces
     * por TU cadena: la primera filtra el leak, la segunda dispara. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[C5] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- ret #1: leak | ret #2: system("/bin/sh") */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* pipes ordenados */
    setvbuf(stdin, NULL, _IONBF, 0);   /* el shell de la etapa 2 */
    puts("[C5] ASLR ACTIVADA: la base de libc cambia en cada ejecucion.");
    victima();
    puts("[C5] retorno LIMPIO: si lees esto, no hubo exploit.");
    return 0;
}
