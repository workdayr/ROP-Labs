/* C6 - Integrador: alineacion + DOS argumentos + llamada doble.
 * Serie: Laboratorio de Practicas ROP - Parte 3 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o c6_final c6_final.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * El examen final de la serie guiada: UNA sola entrada de gets() debe
 *   1) llamar flag_printer(0xcafebabe, 0x8badf00d)  (RDI + RSI),
 *   2) sobrevivir a la alineacion de movaps de printf,
 *   3) ENCADENAR despues system("/bin/sh") con gadgets de libc
 *      (ASLR desactivada + base de `setarch $(uname -m) -R ldd`).
 *
 * La cadena consume casilla tras casilla: el ret de flag_printer es el
 * que entrega el control al siguiente trampolin. Gadgets embebidos
 * (g_pop_rdi, g_pop_rsi, g_ret) + base de libc leida con ldd. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Gadgets embebidos para la primera mitad de la cadena; la segunda
 * mitad (system) usa trampolines de libc, ya con la base conocida. */
__asm__(
    ".globl g_pop_rdi\n"
    "g_pop_rdi:\n"
    "    pop %rdi\n"
    "    ret\n"
    ".globl g_pop_rsi\n"
    "g_pop_rsi:\n"
    "    pop %rsi\n"
    "    ret\n"
    ".globl g_ret\n"
    "g_ret:\n"
    "    ret\n"
);

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void flag_printer(int a, int b)
{
    if (a == 0xcafebabe && b == 0x8badf00d) {
        printf("[flag_printer] FLAG{ROP_C6_integrador_doble_llamada}\n");
    } else {
        printf("[flag_printer] argumentos incorrectos: (0x%x, 0x%x); "
               "esperaba (0xcafebabe, 0x8badf00d)\n", (unsigned int)a,
               (unsigned int)b);
    }
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[C6] victima() en ejecucion; UNA entrada, DOS objetivos\n");
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: gets() sin limite; una sola linea alimenta la cadena
     * completa: argumentos, flag_printer y el ret2libc final. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[C6] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- arranca la cadena integradora */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* pipes ordenados */
    setvbuf(stdin, NULL, _IONBF, 0);   /* el shell necesita stdin limpio */
    printf("[C6] PID=%d | flag_printer(0xcafebabe,0x8badf00d) + system\n",
           getpid());
    victima();
    printf("[C6] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
