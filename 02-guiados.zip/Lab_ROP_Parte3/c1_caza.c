/* C1 - Caza de gadgets: tu primer inventario real y una cadena a mano.
 * Serie: Laboratorio de Practicas ROP - Parte 3 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -static -o c1_caza c1_caza.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * print_flag(int a, int b) exige DOS argumentos (RDI=0x1337, RSI=0x7331)
 * y NADIE la llama: tendras que cazar los trampolines con
 *   ROPgadget --binary ./c1_caza --only "pop|ret"
 *   ropper --file ./c1_caza --search "pop r??"
 * El binario es ESTATICO: cientos de gadgets reales dentro, ninguno
 * embebido a proposito. La cadena es tuya: [pop_rdi][0x1337][pop_rsi]
 * [0x7331][print_flag]. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void print_flag(int a, int b)
{
    if (a == 0x1337 && b == 0x7331) {
        printf("[print_flag] FLAG{ROP_C1_caza_de_gadgets}\n");
    } else {
        printf("[print_flag] argumentos incorrectos: (0x%x, 0x%x); "
               "esperaba (0x1337, 0x7331)\n", (unsigned int)a,
               (unsigned int)b);
    }
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[C1] victima() en ejecucion; buffer en %p\n", (void *)buffer);
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: gets() no limita la longitud y la entrada alimenta
     * el desbordamiento hasta el retorno guardado. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[C1] EOF recibido.\n");
        exit(1);
    }
    printf("[C1] escribiste: %s\n", buffer);
    return;            /* <- el ret arranca TU cadena de gadgets */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: util para pipes */
    printf("[C1] PID=%d | print_flag(0x1337, 0x7331) te espera; nadie la llama\n",
           getpid());
    victima();
    printf("[C1] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
