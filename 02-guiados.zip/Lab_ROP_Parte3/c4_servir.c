/* C4 - Explotacion "remota": el binario se sirve por TCP con socat.
 * Serie: Laboratorio de Practicas ROP - Parte 3 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o c4_servir c4_servir.c
 * Servir:      socat TCP-LISTEN:1337,reuseaddr,fork EXEC:./c4_servir
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * El reto en si es un ret2win humilde (win() sin argumentos, buffer de
 * 32 bytes): la leccion es el FLUJO REMOTO. Tu exploit habla con un
 * proceso cuyo stdin/stdout son un socket, no un pipe:
 *   - remote() no produce corefile: el offset se mide LOCAL y se reutiliza.
 *   - Con EXEC (sin pty) el buffering lo controla setvbuf del fuente.
 *   - gets() puede comerse la primera linea si no esperas el banner:
 *     recvuntil() ANTES de sendline(), siempre. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void win(void)
{
    printf("[win] FLAG{ROP_C4_explotacion_remota_socat}\n");
}

void victima(void)
{
    char buffer[32];   /* 32 bytes legales; offset 48 medido con cyclic */

    printf("[C4] conexion recibida; habla, remote()\n");
    fflush(stdout);    /* orden determinista cuando stdout es un socket */
    /* VULNERABLE: gets() sin limite; la entrada sobra hasta el retorno. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[C4] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- el ret salta a win() si tu payload manda */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* IMPRESCINDIBLE sobre socket */
    setvbuf(stdin, NULL, _IONBF, 0);   /* remote() vs process(): buffering */
    printf("[C4] PID=%d | servido por socat en el puerto 1337\n", getpid());
    victima();
    printf("[C4] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
