#!/bin/bash
# =============================================================
# setup.sh - Instalacion del entorno para el Laboratorio ROP
# Serie: Laboratorio de Practicas ROP - Parte 1 (x86_64, Kali)
# Probado en Kali Linux 64-bit sobre CPU AMD (x86_64 nativo).
#
# USO RESPONSABLE: este script prepara herramientas de seguridad
# para practicar UNICAMENTE con binarios que tu mismo compilas
# en tu propia VM aislada. Nunca contra sistemas de terceros.
# =============================================================
set -e   # abortar ante el primer error

echo "[*] Actualizando indice de paquetes..."
sudo apt update

echo "[*] Instalando paquetes base (gdb, gcc, python3, git, socat)..."
sudo apt install -y gdb build-essential gcc python3-pip python3-venv git curl wget socat

echo "[*] Instalando pwntools desde los repos de Kali..."
sudo apt install -y python3-pwntools

echo "[*] Instalando herramientas de gadgets ROP..."
sudo apt install -y ropgadget ropper

echo "[*] Instalando GEF (explotacion interactiva dentro de GDB)..."
bash -c "$(curl -fsSL https://gef.blah.cat/sh)"

echo "[*] Copiando fuentes y soluciones del laboratorio..."
LAB_DIR="$HOME/rop-lab"
mkdir -p "$LAB_DIR"/{00-fundamentos,01-resueltos,02-guiados,03-ctfs,src}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR"/a0_sanidad.c   "$SCRIPT_DIR"/a1_crash.c \
   "$SCRIPT_DIR"/a2_offset.c    "$SCRIPT_DIR"/a3_rip.c \
   "$SCRIPT_DIR"/a4_shellcode.c "$LAB_DIR/src/"
cp "$SCRIPT_DIR"/a0_sanidad.py  "$SCRIPT_DIR"/a1_crash.py \
   "$SCRIPT_DIR"/a2_offset.py   "$SCRIPT_DIR"/a3_rip.py \
   "$SCRIPT_DIR"/a4_shellcode.py "$LAB_DIR/01-resueltos/"
cp "$SCRIPT_DIR"/build.sh "$LAB_DIR/src/"
chmod +x "$LAB_DIR/src/build.sh"

echo "[+] Estructura creada en $LAB_DIR"
echo "[*] Verificacion rapida del entorno..."
gdb --version | head -1
python3 -c "from pwnlib.version import __version__ as v; print('pwntools', v)" 2>/dev/null \
  || echo "[!] pwntools no importable: mira la seccion 2.7 (troubleshooting) del PDF"
ROPgadget --version 2>/dev/null || echo "[!] ROPgadget ausente"
ropper --version 2>/dev/null || echo "[!] ropper ausente"

echo "[+] Setup completo. Ejecuta ahora: bash build.sh"
