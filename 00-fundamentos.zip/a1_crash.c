/* A1 - Primer crash: gets() sobre char[64] y 100 letras 'A' -> SIGSEGV.
 * Serie: Laboratorio de Practicas ROP - Parte 1 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o a1_crash a1_crash.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[A1] victima() en ejecucion; buffer en %p\n", (void *)buffer);
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: 100 'A' pisian RBP guardado y direccion de retorno.
     * El ret del epilogo carga 0x4141414141414141 en RIP -> SIGSEGV. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[A1] EOF recibido.\n");
        exit(1);
    }
    printf("[A1] escribiste: %s\n", buffer);
    return;            /* <- el estallon ocurre al ejecutar este ret */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: util para pipes */
    printf("[A1] PID=%d | alimentame con 100 letras 'A' y observa SIGSEGV\n",
           getpid());
    victima();
    printf("[A1] retorno LIMPIO: si lees esto, no hubo overflow.\n");
    return 0;
}
