=====================================================================
 LABORATORIO DE PRACTICAS ROP - PARTE 1 de 4
 Entorno Kali y Buffer Overflow (x86_64)
 Paquete de archivos acompanante del PDF
=====================================================================

CONTENIDO
  setup.sh          Instala gdb, gcc, pwntools, GEF, ROPgadget y
                    ropper, y crea la estructura ~/rop-lab.
  build.sh          Compila A0-A4 con las banderas inseguras
                    didacticas que documenta el PDF.
  a0_sanidad.c/.py  A0 - Sanidad: compilar y correr tu primer
                    binario vulnerable.
  a1_crash.c/.py    A1 - Primer crash: gets() sobre char[64] con
                    100 'A' -> SIGSEGV.
  a2_offset.c/.py   A2 - Radiografia: offset exacto al retorno con
                    cyclic() + corefile (o GEF pattern).
  a3_rip.c/.py      A3 - Control de RIP: 'B'*offset + 'C'*8 ->
                    RIP = 0x4343434343434343.
  a4_shellcode.c/.py A4 - ret2shellcode con -z execstack y NOP
                    sled; obtienes un /bin/sh real.

USO RAPIDO (desde esta carpeta, en tu VM Kali)
  1) bash setup.sh          # una sola vez
  2) cd ~/rop-lab/src && bash build.sh
  3) python3 a0_sanidad.py  # avanza en orden A0 -> A4

REQUISITOS
  - Kali Linux 64-bit en CPU x86_64 (AMD o Intel). Los binarios
    se compilan y explotan de forma NATIVA, sin emulacion.
  - Tu GPU NVIDIA no interviene en nada de este laboratorio.
  - Si pip esta bloqueado (PEP 668), el PDF (seccion 2.7) explica
    el plan B con python3 -m venv.

AVISO DE USO RESPONSABLE
  Este material es educativo. Explota UNICAMENTE los binarios
  que tu mismo compilas con build.sh dentro de tu propia VM
  aislada. Aplicar estas tecnicas contra sistemas de terceros,
  sin autorizacion expresa por escrito, es ilegal en Mexico y en
  practicamente cualquier jurisdiccion (delitos informaticos),
  ademas de contrario a la etica profesional. Conocer como se
  rompe el software es lo que permite construirlo mas duro.
