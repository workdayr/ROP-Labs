/* A3 - Control de RIP: payload 'B'*offset + 'C'*8 -> RIP = 0x4343434343434343.
 * Serie: Laboratorio de Practicas ROP - Parte 1 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o a3_rip a3_rip.c
 * Con el offset de A2, los 8 bytes posteriores al relleno son la nueva
 * direccion de retorno. Si el crash aterriza en 0x4343...4343, tomaste el
 * control del flujo: la habilidad exacta que ROP explota en la Parte 2.
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[64];

    printf("[A3] victima(); buffer en %p\n", (void *)buffer);
    fflush(stdout);
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[A3] EOF recibido.\n");
        exit(1);
    }
    return;   /* ret toma los 8 bytes 'C' como direccion de retorno */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("[A3] PID=%d | objetivo: RIP = 0x4343434343434343\n", getpid());
    victima();
    return 0;
}
