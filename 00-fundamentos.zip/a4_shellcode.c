/* A4 - ret2shellcode con -z execstack: ejecutar shellcode en el stack.
 * Serie: Laboratorio de Practicas ROP - Parte 1 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -z execstack
 *              -o a4_shellcode a4_shellcode.c
 * -z execstack marca la pila como ejecutable (GNU_STACK RWE): desactiva
 * NX SOLO para este binario de laboratorio. El leak de buffer[] es
 * pedagogico (en la vida real lo obtendrias con otro bug, p.ej. un
 * format string). ADVERTENCIA: la direccion del stack bajo GDB difiere
 * de la del proceso real; este binario imprime la suya y el exploit la
 * lee del leak, usando ademas un NOP sled como amortiguador.
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[128];   /* espacio de sobra para NOP sled + shellcode */

    printf("[A4] leak: buffer en %p\n", (void *)buffer);
    fflush(stdout);     /* imprescindible: el exploit lee el leak por pipe */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[A4] EOF recibido.\n");
        exit(1);
    }
    return;             /* ret -> NOP sled -> shellcode -> /bin/sh */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("[A4] PID=%d | ret2shellcode con pila ejecutable\n", getpid());
    victima();
    return 0;
}
