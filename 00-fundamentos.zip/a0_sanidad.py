#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A0 - Sanidad: comprobar que el primer binario del lab compila y responde.
USO: python3 a0_sanidad.py"""
from pwn import *

context.arch = 'amd64'          # x86_64: endianness, bits y sintaxis
context.log_level = 'info'

BIN = './a0_sanidad'

# Compilar EXACTAMENTE con la plantilla del lab:
#   -g info de depuracion | -O0 sin optimizar (layout predecible)
#   -fno-stack-protector sin canario | -no-pie ancla el binario en 0x400000
compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'a0_sanidad.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()     # subprocess + comprobacion de exit code

# checksec: inventario de protecciones del binario recien compilado
elf = ELF(BIN, checksec=True)   # imprime NX/PIE/canary/RELRO por ti

# Ejecutar y conversar: stdin/stdout por pipe, como hara el exploit
io = process(BIN)
io.recvuntil(b'Escribe tu nombre y pulsa ENTER:')   # sincronizar con prompt
io.sendline(b'hola-lab')                            # entrada LEGAL (< 64)
resultado = io.recvline()                           # leer la respuesta
io.close()

if b'hola-lab' in resultado:
    log.success('A0 SUPERADO: el binario compila, corre y responde.')
    log.info('Siguiente parada: A1, donde el mismo patron si estalla.')
else:
    log.failure('A0: respuesta inesperada. Revisa la compilacion.')
