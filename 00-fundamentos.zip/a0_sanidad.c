/* A0 - Sanidad: compilar y ejecutar el primer binario vulnerable del lab.
 * Serie: Laboratorio de Practicas ROP - Parte 1 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o a0_sanidad a0_sanidad.c
 * USO RESPONSABLE: ejecutalo solo en tu propia VM Kali aislada. */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* PITFALL: gcc moderno ya no declara gets() (retirada de C11); el
 * prototipo a mano evita el error "implicit declaration". glibc aun
 * exporta el simbolo, asi que el enlace funciona normalmente. */
extern char *gets(char *s);

int main(void)
{
    char nombre[64];   /* 64 bytes: nuestro campo de pruebas */

    printf("[A0] Tu primer binario vulnerable esta vivo.\n");
    printf("[A0] direccion de nombre[]: %p\n", (void *)nombre);
    printf("[A0] Escribe tu nombre y pulsa ENTER: ");
    fflush(stdout);    /* PITFALL: con entrada por pipe, sin esto el
                        * mensaje no sale ANTES de que gets() se bloquee */
    if (gets(nombre) == NULL) {          /* VULNERABLE: sin limite */
        fprintf(stderr, "[A0] EOF recibido: sin datos.\n");
        return 1;
    }
    printf("[A0] Hola, %s\n", nombre);
    printf("[A0] tu nombre mide %lu bytes y no ha pasado nada... aun.\n",
           strlen(nombre));
    return 0;
}
