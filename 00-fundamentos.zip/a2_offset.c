/* A2 - Radiografia con GDB+GEF: medir el offset exacto hasta RIP guardado.
 * Serie: Laboratorio de Practicas ROP - Parte 1 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o a2_offset a2_offset.c
 * El binario es identico en estructura al de A1: aqui el objetivo es MEDIR,
 * no romper. ADVERTENCIA x86_64: el offset se lee desde $rsp, porque el ret
 * ya "consumio" la direccion de retorno del tope del stack antes de estallar.
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[64];

    printf("[A2] victima(); buffer en %p; enviame un patron ciclico largo\n",
           (void *)buffer);
    fflush(stdout);
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[A2] EOF recibido.\n");
        exit(1);
    }
    return;   /* ret consume la direccion de retorno adulterada */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("[A2] PID=%d listo para el patron ciclico\n", getpid());
    victima();
    return 0;
}
