#!/bin/bash
# =============================================================
# build.sh - Compila los 5 binarios del laboratorio (A0-A4)
# con las MISMAS banderas que imprime el PDF, Parte 1.
#
# Las banderas inseguras son intencionales y pedagogicas:
#   -g                    info de depuracion para GDB/GEF
#   -O0                   sin optimizar: layout de stack predecible
#   -fno-stack-protector  quita el canario que abortaria el overflow
#   -no-pie               direcciones fijas (binario en 0x400000)
#   -z execstack          pila ejecutable, SOLO para A4 (shellcode)
# =============================================================
set -e

echo "[*] Compilando A0-A4 con flags inseguras didacticas..."

gcc -g -O0 -fno-stack-protector -no-pie -o a0_sanidad   a0_sanidad.c
gcc -g -O0 -fno-stack-protector -no-pie -o a1_crash     a1_crash.c
gcc -g -O0 -fno-stack-protector -no-pie -o a2_offset    a2_offset.c
gcc -g -O0 -fno-stack-protector -no-pie -o a3_rip       a3_rip.c
gcc -g -O0 -fno-stack-protector -no-pie -z execstack -o a4_shellcode a4_shellcode.c

echo "[+] Compilacion lista. Chequeo rapido de protecciones:"
echo "-----------------------------------------------------"
for b in a0_sanidad a1_crash a2_offset a3_rip a4_shellcode; do
    echo "==> $b"
    pwn checksec "$b" 2>/dev/null || checksec --file="$b" 2>/dev/null || true
done
echo "-----------------------------------------------------"
echo "[+] Ejecuta cada solucion con:  python3 aN_*.py  (desde esta carpeta)"
