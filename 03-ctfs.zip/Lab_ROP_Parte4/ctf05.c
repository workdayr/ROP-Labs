/* CTF-05 (dificultad: 3 estrellas) - "Eco desde el abismo".
 * Serie: Laboratorio de Prácticas ROP - Parte 4 (x86_64, Kali Linux)
 * Compilación: gcc -g -O0 -fno-stack-protector -no-pie -o ctf05 ctf05.c
 * USO RESPONSABLE: binario de práctica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * ASLR ACTIVADA: aquí ni setarch ni ldd te dan la base; cambia en cada
 * ejecución. Lo único que el binario pone a tu alcance: el trampolín
 * embebido g_pop_rdi (verifícalo con ROPgadget), la PLT y la GOT.
 * Grítale a puts lo que quieres que imprima, recoge el eco y vuelve:
 * el abismo responde dos veces a quien sabe preguntar. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Gadgets embebidos: imprescindibles mientras la libc siga siendo un
 * misterio. Verifícalos: ROPgadget --binary ./ctf05 --only "pop|ret" */
__asm__(
    ".globl g_pop_rdi\n"
    "g_pop_rdi:\n"
    "    pop %rdi\n"
    "    ret\n"
    ".globl g_ret\n"
    "g_ret:\n"
    "    ret\n"
);

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahí es tuyo */

    puts("[CTF-05] victima() abierta; acepta una linea:");
    /* VULNERABLE: gets() sin límite; esta función puede ser visitada
     * las veces que TU cadena decida. Cada visita, una linea. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[CTF-05] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- ret #1 y ret #2: el abismo escucha dos veces */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* pipes ordenados */
    setvbuf(stdin, NULL, _IONBF, 0);   /* el shell final necesita stdin limpio */
    puts("[CTF-05] ASLR ACTIVADA: la base cambia en cada ejecucion.");
    victima();
    puts("[CTF-05] retorno LIMPIO: si lees esto, nadie preguntó nada.");
    return 0;
}
