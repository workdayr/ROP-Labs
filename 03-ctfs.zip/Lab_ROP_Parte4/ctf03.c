/* CTF-03 (dificultad: 2 estrellas) - "El estanque ejecutable".
 * Serie: Laboratorio de Prácticas ROP - Parte 4 (x86_64, Kali Linux)
 * Compilación: gcc -g -O0 -fno-stack-protector -no-pie -z execstack
 *              -o ctf03 ctf03.c
 * USO RESPONSABLE: binario de práctica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * Aquí no hay win() que valga: la recompensa es EJECUTAR tu propio
 * código. El binario se compiló con -z execstack (GNU_STACK RWE: pila
 * ejecutable) y su rutina de "depuración" imprime dónde vive buffer[].
 * Lee, apunta y nada en el estanque. Recuerda: gets() copia TODA la
 * línea, y las direcciones bajo GDB no son las del proceso real. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[128];  /* espacio de sobra para lo que tú decidas sembrar */

    printf("[CTF-03] debug: buffer en %p\n", (void *)buffer);
    fflush(stdout);    /* imprescindible: el exploit lee el leak por pipe */
    /* VULNERABLE: gets() sin límite; el retorno te lleva donde tú
     * escribas: al estanque, si lo preparaste bien. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[CTF-03] EOF recibido.\n");
        exit(1);
    }
    return;            /* ret -> hacia TU código, si la pila ejecuta */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: útil para pipes */
    printf("[CTF-03] PID=%d | estanque RWE: el agua es tuya\n", getpid());
    victima();
    return 0;
}
