/* CTF-01 (dificultad: 1 estrella) - "La bóveda olvidada".
 * Serie: Laboratorio de Prácticas ROP - Parte 4 (x86_64, Kali Linux)
 * Compilación: gcc -g -O0 -fno-stack-protector -no-pie -o ctf01 ctf01.c
 * USO RESPONSABLE: binario de práctica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * La bóveda guarda su secreto en flag.txt (mismo directorio del binario).
 * win() existe, imprime el secreto... y nadie la llama. El flujo normal
 * muere en victima(), que lee con gets() sin límite alguno.
 * Nada de pistas: ya sabes reconocer este patrón. O casi. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void win(void)
{
    char linea[64];
    FILE *f = fopen("flag.txt", "r");
    if (!f) {
        printf("[win] flag.txt no encontrado en el directorio actual\n");
        return;
    }
    if (fgets(linea, sizeof linea, f))
        printf("[win] FLAG: %s", linea);
    fclose(f);
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahí es tuyo */

    printf("[CTF-01] la bóveda escucha; escribe tu nombre:\n");
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: gets() sin límite; lo que siga al relleno es la
     * dirección de retorno que ret consumirá al volver. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[CTF-01] EOF recibido.\n");
        exit(1);
    }
    printf("[CTF-01] saludaste como: %s\n", buffer);
    return;            /* <- aquí decide TU payload quién sigue */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: útil para pipes */
    printf("[CTF-01] PID=%d | bóveda v2.3; el mantenimiento nunca llegó\n",
           getpid());
    victima();
    printf("[CTF-01] retorno LIMPIO: si lees esto, el intento no tocó nada.\n");
    return 0;
}
