/* CTF-02 (dificultad: 2 estrellas) - "Los dos sellos".
 * Serie: Laboratorio de Prácticas ROP - Parte 4 (x86_64, Kali Linux)
 * Compilación: gcc -g -O0 -fno-stack-protector -no-pie -o ctf02 ctf02.c
 * USO RESPONSABLE: binario de práctica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * win(int a, int b) solo abre la cámara si RDI y RSI llevan los DOS
 * sellos correctos a la vez. El binario es dinámico moderno: no esperes
 * trampolines "de regalo"; los autores del reto los dejaron EMBEBIDOS
 * en el fuente (g_pop_rdi, g_pop_rsi, g_ret). Verifícalos tú:
 *   ROPgadget --binary ./ctf02 --only "pop|ret"
 * Sin PIE: símbolos y gadgets quedan fijos aunque ASLR esté activada. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Gadgets embebidos: etiquetas globales apuntando a instrucciones
 * exactas; el ensamblador las coloca en .text y ROPgadget las ve. */
__asm__(
    ".globl g_pop_rdi\n"
    "g_pop_rdi:\n"
    "    pop %rdi\n"
    "    ret\n"
    ".globl g_pop_rsi\n"
    "g_pop_rsi:\n"
    "    pop %rsi\n"
    "    ret\n"
    ".globl g_ret\n"
    "g_ret:\n"
    "    ret\n"
);

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void win(int a, int b)
{
    if (a == 0x1337c0de && b == 0x600dc0de) {
        char linea[64];
        FILE *f = fopen("flag.txt", "r");
        if (!f) {
            printf("[win] sellos correctos, pero flag.txt no está aquí\n");
            return;
        }
        if (fgets(linea, sizeof linea, f))
            printf("[win] FLAG: %s", linea);
        fclose(f);
    } else {
        printf("[win] sellos rechazados: (0x%x, 0x%x)\n",
               (unsigned int)a, (unsigned int)b);
    }
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahí es tuyo */

    printf("[CTF-02] la cámara pide DOS sellos; presenta los tuyos:\n");
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: gets() sin límite; una sola línea alimenta toda la
     * cadena que cargue RDI y RSI antes de saltar a win(). */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[CTF-02] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- el ret arranca TU cadena de gadgets */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: útil para pipes */
    printf("[CTF-02] PID=%d | cámara de doble sello, serie BX-1337\n",
           getpid());
    victima();
    printf("[CTF-02] retorno LIMPIO: si lees esto, la cadena no llegó.\n");
    return 0;
}
