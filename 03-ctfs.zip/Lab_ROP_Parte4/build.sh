#!/bin/sh
# build.sh - Laboratorio de Practicas ROP, Parte 4 (CTFs CTF-01..06)
# Compila los 6 binarios EXACTAMENTE con las banderas impresas en el PDF.
# Uso:  cd ~/rop-lab/parte4 && sh build.sh
set -e

echo "[build.sh] Compilando los CTF CTF-01..06..."

# CTF-01 - ret2win con trampa de alineacion (win() usa printf: movaps)
gcc -g -O0 -fno-stack-protector -no-pie -o ctf01 ctf01.c

# CTF-02 - win(int,int): dos valores magicos por RDI y RSI
gcc -g -O0 -fno-stack-protector -no-pie -o ctf02 ctf02.c

# CTF-03 - ret2shellcode: pila EJECUTABLE (-z execstack, GNU_STACK RWE)
gcc -g -O0 -fno-stack-protector -no-pie -z execstack -o ctf03 ctf03.c

# CTF-04 - ret2libc sin "/bin/sh" en el binario (localizalo en libc)
gcc -g -O0 -fno-stack-protector -no-pie -o ctf04 ctf04.c

# CTF-05 - leak en dos etapas con ASLR ACTIVADA
gcc -g -O0 -fno-stack-protector -no-pie -o ctf05 ctf05.c

# CTF-06 - doble llamada encadenada (setup -> win) + alineacion extra
gcc -g -O0 -fno-stack-protector -no-pie -o ctf06 ctf06.c

echo "[build.sh] 6 binarios listos. Notas:"
echo "  - El warning 'gets is dangerous' es ESPERADO: es la vulnerabilidad."
echo "  - Crea tu flag.txt por reto (si no existe ya):"
echo "      echo \"FLAG{tu_flag_de_practica}\" > flag.txt"
echo "  - CTF-03 verifica RWX con:  pwn checksec ./ctf03"
echo "  - CTF-04 se explota con ASLR desactivada (misma via para ldd y"
echo "    para el binario):  setarch \$(uname -m) -R ldd ./ctf04"
echo "  - CTF-05 se explota con ASLR ACTIVADA (la gracia es el leak)."
