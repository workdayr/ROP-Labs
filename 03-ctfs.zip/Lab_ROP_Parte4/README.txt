================================================================
 LABORATORIO DE PRACTICAS ROP - PARTE 4 DE 4: CTFS Y SOLUCIONARIO
 x86_64 - Kali Linux - pwntools
================================================================

CONTENIDO
---------
6 CTFs SIN pistas (CTF-01..06) y sus solucionarios pwntools
verificados. ANTES de abrir un solucionario: minimo 45 minutos
por reto (regla del PDF).

  CTF-01  ctf01.c      / sol_ctf01.py   ret2win con trampa de
                                        alineacion (movaps)
  CTF-02  ctf02.c      / sol_ctf02.py   win(int,int): DOS sellos
                                        por RDI y RSI (gadgets
                                        embebidos)
  CTF-03  ctf03.c      / sol_ctf03.py   ret2shellcode con pila
                                        ejecutable (-z execstack)
  CTF-04  ctf04.c      / sol_ctf04.py   ret2libc sin "/bin/sh" en
                                        el binario (localizalo en
                                        la libc de tu VM)
  CTF-05  ctf05.c      / sol_ctf05.py   leak en dos etapas con
                                        ASLR ACTIVADA
  CTF-06  ctf06.c      / sol_ctf06.py   doble llamada encadenada
                                        (setup -> win) con
                                        alineacion extra
  build.sh             Compila los 6 binarios con las banderas
                       exactas del PDF.

INSTALACION RAPIDA
------------------
  mkdir -p ~/rop-lab/parte4 && cd ~/rop-lab/parte4
  # copia aqui los archivos de este ZIP
  sh build.sh

El warning "the `gets' function is dangerous" es ESPERADO: gets()
es la vulnerabilidad.

REGLAS DEL JUEGO (resumen)
--------------------------
1. Crea flag.txt junto al binario ANTES de explotar:
     echo "FLAG{tu_flag_de_practica}" > flag.txt
   (los solucionarios crean una de practica solo si no existe).
2. Minimo 45 minutos por reto antes de abrir el Apendice A.
3. Anota cada intento en la bitacora del PDF (Cap. 1).
4. Consultar las Partes 1-3: SI. Mirar la solucion antes de
   tiempo: NO.

NOTAS POR RETO
--------------
- CTF-01: sin setarch; la trampa es la alineacion de win().
- CTF-02: sin setarch; gadgets g_pop_rdi/g_pop_rsi/g_ret
  embebidos (verificalos con ROPgadget --binary ./ctf02
  --only "pop|ret").
- CTF-03: verifica RWX con pwn checksec ./ctf03; el leak de
  buffer[] es parte del diseno del reto.
- CTF-04: SIEMPRE lanza el binario con la misma via que el ldd:
      setarch $(uname -m) -R ./ctf04
      setarch $(uname -m) -R ldd ./ctf04
- CTF-05: ASLR ACTIVADA (sin setarch). Si el leak sale truncado
  (un 0x0a en la direccion), el solucionario reintenta solo.
- CTF-06: dos llamadas en UNA cadena; win() se niega si nadie
  llamo antes a setup() con el modo correcto.

ETICA
-----
Estos binarios son para practicar en TU VM Kali aislada. Las
tecnicas del laboratorio son ilegales contra sistemas de terceros
sin autorizacion por escrito. Solo binarios propios, solo
laboratorio.

Serie completa: Parte 1 (A0-A4) - Parte 2 (B1-B4) -
Parte 3 (C1-C6) - Parte 4 (CTF-01..06).
