/* CTF-04 (dificultad: 3 estrellas) - "Sin brújula".
 * Serie: Laboratorio de Prácticas ROP - Parte 4 (x86_64, Kali Linux)
 * Compilación: gcc -g -O0 -fno-stack-protector -no-pie -o ctf04 ctf04.c
 * USO RESPONSABLE: binario de práctica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * Este binario NO contiene la cadena "/bin/sh" (compruébalo: strings
 * ./ctf04 | grep bin) y tampoco llama a system(): NX bloquea la pila y
 * no hay win() que regale nada. La única ejecutable "amable" del
 * proceso es la libc de TU VM: localiza en ella lo que necesitas y
 * trae las direcciones de vuelta. Con ASLR desactivada la base se LEE,
 * no se adivina: setarch $(uname -m) -R ldd ./ctf04
 * (y lanza el binario por la misma vía: setarch $(uname -m) -R ./ctf04)
 * PITFALL heredado: setvbuf(stdin, _IONBF) deja los comandos del shell
 * en la tubería en vez de tragárselos gets(). */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[32];   /* 32 bytes legales; offset corto, cadena larga */

    printf("[CTF-04] canal abierto; ordene, navegante:\n");
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: gets() sin límite; el retorno consumirá la primera
     * casilla de TU cadena (hint no incluido: el título basta). */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[CTF-04] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- aquí empieza la travesía hacia libc */
}

int main(void)
{
    /* SIN buffering en stdin: gets() consume SOLO su línea y los
     * comandos siguientes quedan en la tubería para el shell final. */
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("[CTF-04] PID=%d | ni system ni cadenas útiles a bordo\n",
           getpid());
    victima();
    printf("[CTF-04] retorno LIMPIO: si lees esto, no hubo abordaje.\n");
    return 0;
}
