/* CTF-06 (dificultad: 4 estrellas) - "Protocolo de doble llave".
 * Serie: Laboratorio de Prácticas ROP - Parte 4 (x86_64, Kali Linux)
 * Compilación: gcc -g -O0 -fno-stack-protector -no-pie -o ctf06 ctf06.c
 * USO RESPONSABLE: binario de práctica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * El desafío final de la serie: UNA sola línea de gets() debe ENCADENAR
 * dos llamadas en el orden correcto:
 *   1) setup(modo) con el modo que desbloquea la maquinaria (variable
 *      global sello: sin ella, win() se niega a abrir la cámara),
 *   2) win(a, b) con los DOS sellos definitivos por RDI y RSI.
 * printf vive dentro de ambas funciones: la pila no perdona ninguna
 * entrada desalineada. Los trampolines van embebidos (g_pop_rdi,
 * g_pop_rsi, g_ret); verifícalos con ROPgadget y cuenta tus casillas. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Gadgets embebidos: fijos por No PIE. Cuenta con ellos, no con la
 * suerte: cada llamada de la cadena exige su propia revisión. */
__asm__(
    ".globl g_pop_rdi\n"
    "g_pop_rdi:\n"
    "    pop %rdi\n"
    "    ret\n"
    ".globl g_pop_rsi\n"
    "g_pop_rsi:\n"
    "    pop %rsi\n"
    "    ret\n"
    ".globl g_ret\n"
    "g_ret:\n"
    "    ret\n"
);

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

static int sello = 0;   /* 0 = maquinaria bloqueada */

void setup(int modo)
{
    if (modo == 0x72756e31) {          /* el modo que activa la planta */
        sello = 1;
        printf("[setup] maquinaria desbloqueada\n");
    } else {
        printf("[setup] modo invalido: 0x%x\n", (unsigned int)modo);
    }
}

void win(int a, int b)
{
    if (sello != 1) {
        printf("[win] camara bloqueada: la maquinaria sigue apagada\n");
        return;
    }
    if (a == 0xfeedface && b == 0xdeadfa11) {
        char linea[64];
        FILE *f = fopen("flag.txt", "r");
        if (!f) {
            printf("[win] sellos correctos, pero flag.txt no está aquí\n");
            return;
        }
        if (fgets(linea, sizeof linea, f))
            printf("[win] FLAG: %s", linea);
        fclose(f);
    } else {
        printf("[win] sellos rechazados: (0x%x, 0x%x)\n",
               (unsigned int)a, (unsigned int)b);
    }
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; una línea, todo el protocolo */

    printf("[CTF-06] planta apagada; el protocolo exige DOS llaves:\n");
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: gets() sin límite; una sola línea debe encadenar
     * setup() y después win(): el ret de la primera entrega el control
     * a la segunda mitad de TU cadena. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[CTF-06] EOF recibido.\n");
        exit(1);
    }
    return;            /* <- arranca el protocolo de doble llave */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: útil para pipes */
    setvbuf(stdin, NULL, _IONBF, 0);
    printf("[CTF-06] PID=%d | setup(modo) y win(a,b): dos llamadas, "
           "una cadena\n", getpid());
    victima();
    printf("[CTF-06] retorno LIMPIO: si lees esto, el protocolo no arrancó.\n");
    return 0;
}
