#!/usr/bin/env bash
# build.sh - Compila los binarios B1-B4 de la Parte 2 con las banderas
# EXACTAS que se imprimen en el PDF (Lab_ROP_Parte2_ROP_Resuelto.pdf).
# Serie: Laboratorio de Practicas ROP - Parte 2 (x86_64, Kali Linux)
# USO RESPONSABLE: solo binarios propios en tu VM Kali aislada.
set -euo pipefail

cd "$(dirname "$0")"

FLAGS="-g -O0 -fno-stack-protector -no-pie"

echo "[*] Compilando B1-B4 con flags: $FLAGS"

gcc $FLAGS -o b1_ret2win      b1_ret2win.c        2>/dev/null || gcc $FLAGS -o b1_ret2win      b1_ret2win.c
gcc $FLAGS -o b2_ret2libc     b2_ret2libc.c       2>/dev/null || gcc $FLAGS -o b2_ret2libc     b2_ret2libc.c
gcc $FLAGS -o b3_ret2win_arg  b3_ret2win_arg.c    2>/dev/null || gcc $FLAGS -o b3_ret2win_arg  b3_ret2win_arg.c
gcc $FLAGS -o b4_cadena       b4_cadena.c         2>/dev/null || gcc $FLAGS -o b4_cadena       b4_cadena.c

echo "[*] Banderas usadas (verificacion):"
for b in b1_ret2win b2_ret2libc b3_ret2win_arg b4_cadena; do
    pwn checksec "./$b" | sed "s/^/    /"
done

# flag de practica: solo si no existe (no pisa la tuya)
if [ ! -f flag.txt ]; then
    echo "flag{ROP_B1_ret2win_alineado}" > flag.txt
    echo "[*] flag.txt de practica creada (B1). Puedes escribir la tuya."
fi

echo "[OK] Binarios listos. Ejecuta las soluciones:"
echo "     python3 b1_ret2win.py    # ret2win + trampa movaps"
echo "     python3 b2_ret2libc.py   # ret2libc con base via ldd (ASLR fuera)"
echo "     python3 b3_ret2win_arg.py# win(int) exige 0x1337 en RDI"
echo "     python3 b4_cadena.py     # cadena multi-gadget (pop rdi + pop rsi)"
