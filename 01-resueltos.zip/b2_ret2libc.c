/* B2 - ret2libc con ASLR desactivada: pop rdi; "/bin/sh"; system.
 * Serie: Laboratorio de Practicas ROP - Parte 2 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o b2_ret2libc b2_ret2libc.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * NX esta activo (pila NO ejecutable): ret2shellcode de la Parte 1 aqui
 * no funciona. ROP no inyecta codigo: ejecuta system(), ya presente en
 * libc, con rdi apuntando a "/bin/sh". Con ASLR fuera, la base de libc
 * es fija y se lee con ldd (ver exploit).
 *
 * PITFALL resuelto aqui: setvbuf(stdin, _IONBF) deja sin buffering la
 * entrada; sin el, stdio se "tragaria" los comandos que el shell debe
 * leer despues del exploit (gets se los lleva al bufer del proceso). */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[B2] victima() en ejecucion; buffer en %p\n", (void *)buffer);
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: el overflow aplasta la direccion de retorno y ret
     * saltara al gadget 'pop rdi; ret' que vive dentro de libc. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[B2] EOF recibido.\n");
        exit(1);
    }
    printf("[B2] escribiste: %s\n", buffer);
    return;            /* <- comienza la cadena ROP aqui */
}

int main(void)
{
    /* SIN buffering en stdin: gets() consume SOLO su linea y los
     * comandos siguientes quedan en la tuberia para /bin/sh. */
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("[B2] PID=%d | NX activo: la pila no ejecuta, pero libc si\n",
           getpid());
    victima();
    printf("[B2] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
