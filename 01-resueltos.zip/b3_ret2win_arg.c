/* B3 - ret2win con argumento: win(int) exige 0x1337 en RDI.
 * Serie: Laboratorio de Practicas ROP - Parte 2 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o b3_ret2win_arg b3_ret2win_arg.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * Salto a win() NO basta: la convencion System V AMD64 exige el primer
 * argumento en RDI. El exploit carga 0x1337 en RDI con el gadget
 * 'pop rdi; ret' (tomado de libc: el binario moderno no lo tiene). */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void win(int clave)
{
    if (clave == 0x1337) {
        printf("[win] clave correcta (0x1337): FLAG{ROP_B3_pop_rdi_0x1337}\n");
    } else {
        /* Aqui aterrizas si saltas a win() sin preparar RDI:
         * veras el valor basura que tuviera el registro en ese momento. */
        printf("[win] clave INCORRECTA: win(0x%x); esperaba 0x1337\n",
               (unsigned int)clave);
    }
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[B3] victima() en ejecucion; buffer en %p\n", (void *)buffer);
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: ademas de controlar RIP, hoy controlas QUE RECIBE
     * la funcion destino, porque los gadgets consumen la pila como
     * si fueran instrucciones tuyas. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[B3] EOF recibido.\n");
        exit(1);
    }
    printf("[B3] escribiste: %s\n", buffer);
    return;            /* <- ret inicia la cadena: pop rdi; ret; win */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: util para pipes */
    printf("[B3] PID=%d | win() exige 0x1337 en RDI (System V)\n", getpid());
    victima();
    printf("[B3] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
