/* B1 - ret2win 64-bit: sobrescribe el retorno con la direccion de win().
 * Serie: Laboratorio de Practicas ROP - Parte 2 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o b1_ret2win b1_ret2win.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * win() imprime flag.txt. Nunca es llamada desde main: solo es alcanzable
 * si TU rediriges el flujo con la direccion de retorno sobrescrita.
 * ADVERTENCIA (trampa de alineacion): saltar a win() sin ajustar la pila
 * la deja desalineada en 8 bytes y printf puede morir en movaps. El
 * exploit B1 demuestra el crash y luego lo corrige con un gadget ret. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void win(void)
{
    char linea[64];
    FILE *f = fopen("flag.txt", "r");
    if (!f) {
        printf("[win] flag.txt no encontrado en el directorio actual\n");
        return;
    }
    if (fgets(linea, sizeof linea, f))
        printf("[win] FLAG: %s", linea);
    fclose(f);
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[B1] victima() en ejecucion; buffer en %p\n", (void *)buffer);
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: 72 'A' llenan buffer + RBP guardado; lo que sigue
     * aplasta la direccion de retorno que ret consumira al volver. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[B1] EOF recibido.\n");
        exit(1);
    }
    printf("[B1] escribiste: %s\n", buffer);
    return;            /* <- aqui salta a donde TU escribas en la pila */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: util para pipes */
    printf("[B1] PID=%d | win() esta en el binario pero nadie la llama\n",
           getpid());
    victima();
    printf("[B1] retorno LIMPIO: si lees esto, no hubo overflow.\n");
    return 0;
}
