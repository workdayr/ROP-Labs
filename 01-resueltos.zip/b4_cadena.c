/* B4 - Cadena multi-gadget: dos llamadas consumiendo la pila.
 * Serie: Laboratorio de Practicas ROP - Parte 2 (x86_64, Kali Linux)
 * Compilacion: gcc -g -O0 -fno-stack-protector -no-pie -o b4_cadena b4_cadena.c
 * USO RESPONSABLE: binario de practica para tu VM Kali aislada. Solo
 * ataques a binarios propios en tu laboratorio; atacar terceros es ilegal.
 *
 * print_flag(int a, int b) exige DOS argumentos (RDI=0x1337, RSI=0x7331)
 * y bonus() debe ejecutarse DESPUES, sin nueva entrada: la cadena ROP
 * apila [pop_rdi][0x1337][pop_rsi][0x7331][ret][print_flag][ret][bonus]
 * y el ret de CADA funcion consume la siguiente casilla de la pila. */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern char *gets(char *s);   /* prototipo manual (gcc moderno no la declara) */

void print_flag(int a, int b)
{
    if (a == 0x1337 && b == 0x7331) {
        printf("[print_flag] FLAG{ROP_B4_cadena_multi_gadget}\n");
    } else {
        printf("[print_flag] argumentos incorrectos: (0x%x, 0x%x); "
               "esperaba (0x1337, 0x7331)\n", (unsigned int)a,
               (unsigned int)b);
    }
}

void bonus(void)
{
    printf("[bonus] cadena completada: print_flag devolvio el control y "
           "el ret consumio la SIGUIENTE casilla.\n");
}

void victima(void)
{
    char buffer[64];   /* 64 bytes legales; lo que pase de ahi es overflow */

    printf("[B4] victima() en ejecucion; buffer en %p\n", (void *)buffer);
    fflush(stdout);    /* orden determinista con entrada por pipe */
    /* VULNERABLE: una sola gets() alimenta TODA la cadena. El ret de
     * victima solo arranca; cada ret posterior come la casilla siguiente. */
    if (gets(buffer) == NULL) {
        fprintf(stderr, "[B4] EOF recibido.\n");
        exit(1);
    }
    printf("[B4] escribiste: %s\n", buffer);
    return;            /* <- arranca la cadena de gadgets */
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);  /* sin buffering: util para pipes */
    printf("[B4] PID=%d | print_flag(0x1337,0x7331) y despues bonus()\n",
           getpid());
    victima();
    printf("[B4] retorno LIMPIO: si lees esto, no hubo exploit.\n");
    return 0;
}
