================================================================================
LABORATORIO DE PRACTICAS ROP - PARTE 2 DE 4
ROP Resuelto paso a paso (x86_64)
Archivos complementarios del PDF: Lab_ROP_Parte2_ROP_Resuelto.pdf
================================================================================

1) USO RESPONSABLE (LEER PRIMERO)
--------------------------------------------------------------------------------
Este material es para practicar explotacion binaria SOLO sobre binarios que tu
compilas en tu propia maquina virtual Kali, aislada y de tu propiedad.
Usar estas tecnicas contra sistemas de terceros sin autorizacion escrita es
ilegal (codigo penal federal en Mexico y casi cualquier jurisdiccion) y
contraria al proposito del laboratorio. La flag.txt de este paquete es un
archivo de practica que tu mismo puedes reescribir.

2) CONTENIDO DEL PAQUETE
--------------------------------------------------------------------------------
  build.sh            Compila B1-B4 con las banderas EXACTAS del PDF.
  b1_ret2win.c/.py    B1: ret2win 64-bit + la trampa de alineacion (movaps)
                      y su solucion con un gadget ret extra.
  b2_ret2libc.c/.py   B2: ret2libc con ASLR fuera; base de libc leida con
                      ldd; pop rdi; ret, system y "/bin/sh" tomados de libc.
  b3_ret2win_arg.c/.py B3: win(int) exige 0x1337 en RDI (pop rdi; ret).
  b4_cadena.c/.py     B4: cadena multi-gadget: print_flag(0x1337, 0x7331)
                      y luego bonus(), con una sola entrada.
  README.txt          Este archivo.

Los .py son las soluciones completas comentadas (exploits pwntools) que
aparecen en el apartado (h) de cada ejercicio del PDF. Los .c son el codigo
del apartado (c) y compilan EXACTAMENTE con los comandos de build.sh.

3) REQUISITOS (heredados de la Parte 1)
--------------------------------------------------------------------------------
  - Kali Linux 64-bit (VM aislada), CPU x86_64 (AMD nativo, sin emulacion).
  - gcc, python3, pwntools 4.x:  sudo apt install -y python3-pwntools
  - ROPgadget (opcional para los pasos manuales):  sudo apt install -y ropgadget
  - gdb + GEF para seguir los pasos de diagnostico del PDF.
  Si falta algo de esto, la Parte 1, capitulo 2, lo instala paso a paso.

4) COMO EMPEZAR
--------------------------------------------------------------------------------
  mkdir -p ~/rop-lab/01-resueltos/parte2
  cp -a ./* ~/rop-lab/01-resueltos/parte2/
  cd ~/rop-lab/01-resueltos/parte2
  ./build.sh                      # compila B1-B4 y crea flag.txt de practica
  python3 b1_ret2win.py           # sigue el orden B1 -> B4

Notas:
  - B1 no necesita ASLR fuera (No PIE fija las direcciones del binario).
  - B2, B3 y B4 lanzan la victima con setarch -R (ASLR fuera) y leen la base
    de libc con ldd; su exploit hace ambas cosas automaticamente.
  - Los exploits son 100% dinamicos: elf.symbols[...], ROP(elf), libc.address
    = base. No hay direcciones hardcodeadas; las que veas impresas son
    ejemplos de una verificacion en x86_64 y en tu VM seran distintas.

5) PITFALLS CUBIERTOS (documentados en el PDF)
--------------------------------------------------------------------------------
  - movaps: crash dentro de printf si saltas a win() sin alinear la pila
    (solucion: gadget ret extra). B1 lo reproduce y lo corrige.
  - pop rdi; ret puede FALTAR en binarios dinamicos modernos (gcc 14): se
    toma de libc con su base correspondiente. B2-B4.
  - ROPgadget separa instrucciones con " ; " (espacio-punto y coma-espacio).
  - El offset del patron ciclico en x86_64 se lee desde $rsp.
  - Sin setvbuf(stdin, _IONBF), stdio se "come" los comandos destinados al
    shell del B2 (el .c de B2 ya lo resuelve).

6) ETICA
--------------------------------------------------------------------------------
Practica en tu VM, ataca tus propios binarios, comparte conocimiento.
Attacks against systems you do not own or do not have written permission to
test are illegal and unacceptable. This lab exists to build judgment, not to
commit crimes.
================================================================================
